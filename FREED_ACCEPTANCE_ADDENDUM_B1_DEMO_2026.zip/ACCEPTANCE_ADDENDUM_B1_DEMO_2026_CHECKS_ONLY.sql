-- ============================================================
-- ACCEPTANCE_ADDENDUM_B1_DEMO_2026_CHECKS_ONLY.sql
-- Post Schema+Seed Acceptance Addendum (Checks-only)
-- Dataset: DEMO_2026
-- Notes:
--   - Checks-only: PASS/FAIL rows only (no heavy diagnostics)
--   - Expected counts are tied to the frozen Seed baseline for DEMO_2026.
--   - Any seed change requires updating expected counts under a documented Fix Attempt.
-- ============================================================

SET @DATASET_ID := 'DEMO_2026';
SET @MONEY_TOLERANCE := 0.0001;
SET @EXPECTED_HASH := '$2b$10$yKfK89/06PEobiIllvmRW.YxOnlfkGxDpSh4KrQHGbe6F6q8GHOUS';

SELECT CONCAT('=== ACCEPTANCE ADDENDUM | Batch 1/4 | DATASET=', @DATASET_ID, ' | CHECKS-ONLY ===') AS banner;

-- ============================================================
-- A) ORPHAN CHECKS (GLOBAL unless stated)
-- ============================================================

/* ORPH-01: users.role_id must reference roles.id (GLOBAL) */
SELECT
  'ORPH-01 users_role_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM users u
LEFT JOIN roles r ON r.id = u.role_id
WHERE u.role_id IS NOT NULL AND r.id IS NULL;

/* ORPH-02: users.department_id must reference departments.id (GLOBAL) */
SELECT
  'ORPH-02 users_department_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM users u
LEFT JOIN departments d ON d.id = u.department_id
WHERE u.department_id IS NOT NULL AND d.id IS NULL;

/* ORPH-03: users.organization_id must reference organizations.id (GLOBAL) */
SELECT
  'ORPH-03 users_organization_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM users u
LEFT JOIN organizations o ON o.id = u.organization_id
WHERE u.organization_id IS NOT NULL AND o.id IS NULL;

/* ORPH-04: departments.organization_id must reference organizations.id (GLOBAL) */
SELECT
  'ORPH-04 departments_organization_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM departments d
LEFT JOIN organizations o ON o.id = d.organization_id
WHERE d.organization_id IS NOT NULL AND o.id IS NULL;

/* ORPH-05: initiatives.organization_id must reference organizations.id (GLOBAL) */
SELECT
  'ORPH-05 initiatives_organization_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM initiatives i
LEFT JOIN organizations o ON o.id = i.organization_id
WHERE i.organization_id IS NOT NULL AND o.id IS NULL;

/* ORPH-06: initiatives.owner_id must reference users.id (GLOBAL) */
SELECT
  'ORPH-06 initiatives_owner_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM initiatives i
LEFT JOIN users u ON u.id = i.owner_id
WHERE i.owner_id IS NOT NULL AND u.id IS NULL;

/* ORPH-07: tasks.initiative_id must reference initiatives.id (GLOBAL) */
SELECT
  'ORPH-07 tasks_initiative_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM tasks t
LEFT JOIN initiatives i ON i.id = t.initiative_id
WHERE t.initiative_id IS NOT NULL AND i.id IS NULL;

/* ORPH-08: allocations.initiative_id must reference initiatives.id (GLOBAL) */
SELECT
  'ORPH-08 allocations_initiative_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM allocations a
LEFT JOIN initiatives i ON i.id = a.initiative_id
WHERE a.initiative_id IS NOT NULL AND i.id IS NULL;

/* ORPH-09: allocations.budget_line_id must reference budget_lines.id (GLOBAL) */
SELECT
  'ORPH-09 allocations_budget_line_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM allocations a
LEFT JOIN budget_lines b ON b.id = a.budget_line_id
WHERE a.budget_line_id IS NOT NULL AND b.id IS NULL;

/* ORPH-10: finance_transactions.initiative_id must reference initiatives.id (GLOBAL) */
SELECT
  'ORPH-10 finance_transactions_initiative_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM finance_transactions ft
LEFT JOIN initiatives i ON i.id = ft.initiative_id
WHERE ft.initiative_id IS NOT NULL AND i.id IS NULL;

/* ORPH-11: finance_transactions.vendor_id must reference vendors.id (GLOBAL) */
SELECT
  'ORPH-11 finance_transactions_vendor_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM finance_transactions ft
LEFT JOIN vendors v ON v.id = ft.vendor_id
WHERE ft.vendor_id IS NOT NULL AND v.id IS NULL;

/* ORPH-12: attachments.organization_id must reference organizations.id (GLOBAL) */
SELECT
  'ORPH-12 attachments_organization_orphans' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM attachments a
LEFT JOIN organizations o ON o.id = a.organization_id
WHERE a.organization_id IS NOT NULL AND o.id IS NULL;

-- ============================================================
-- B) EXPECTED COUNTS (DATASET baseline)
-- ============================================================

/* CNT-01: organizations demo count = 2 */
SELECT
  'CNT-01 demo_organizations_count' AS check_name,
  COUNT(*) AS result_value,
  2 AS expected_value,
  CASE WHEN COUNT(*) = 2 THEN 'PASS' ELSE 'FAIL' END AS result
FROM organizations
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-02: departments demo count = 5 */
SELECT
  'CNT-02 demo_departments_count' AS check_name,
  COUNT(*) AS result_value,
  5 AS expected_value,
  CASE WHEN COUNT(*) = 5 THEN 'PASS' ELSE 'FAIL' END AS result
FROM departments
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-03: roles bootstrap count = 5 (org_id IS NULL, not demo) */
SELECT
  'CNT-03 bootstrap_roles_count' AS check_name,
  COUNT(*) AS result_value,
  5 AS expected_value,
  CASE WHEN COUNT(*) = 5 THEN 'PASS' ELSE 'FAIL' END AS result
FROM roles
WHERE organization_id IS NULL
  AND COALESCE(demo_marker,0) = 0
  AND demo_dataset_id IS NULL;

/* CNT-04: roles demo count = 4 (demo + org-scoped only) */
SELECT
  'CNT-04 demo_roles_count' AS check_name,
  COUNT(*) AS result_value,
  4 AS expected_value,
  CASE WHEN COUNT(*) = 4 THEN 'PASS' ELSE 'FAIL' END AS result
FROM roles
WHERE demo_dataset_id = @DATASET_ID
  AND organization_id IS NOT NULL;

/* CNT-05: users demo count = 3 */
SELECT
  'CNT-05 demo_users_count' AS check_name,
  COUNT(*) AS result_value,
  3 AS expected_value,
  CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END AS result
FROM users
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-06: permissions bootstrap count = 15 (not demo) */
SELECT
  'CNT-06 bootstrap_permissions_count' AS check_name,
  COUNT(*) AS result_value,
  15 AS expected_value,
  CASE WHEN COUNT(*) = 15 THEN 'PASS' ELSE 'FAIL' END AS result
FROM permissions
WHERE COALESCE(demo_marker,0) = 0
  AND demo_dataset_id IS NULL;

/* CNT-07: role_permissions bootstrap count = 11 (bootstrap roles only) */
SELECT
  'CNT-07 bootstrap_role_permissions_count' AS check_name,
  COUNT(*) AS result_value,
  11 AS expected_value,
  CASE WHEN COUNT(*) = 11 THEN 'PASS' ELSE 'FAIL' END AS result
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
WHERE r.organization_id IS NULL
  AND COALESCE(rp.demo_marker,0) = 0
  AND rp.demo_dataset_id IS NULL;

/* CNT-08: role_permissions demo links count = 7 */
SELECT
  'CNT-08 demo_role_permissions_count' AS check_name,
  COUNT(*) AS result_value,
  7 AS expected_value,
  CASE WHEN COUNT(*) = 7 THEN 'PASS' ELSE 'FAIL' END AS result
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
WHERE r.demo_dataset_id = @DATASET_ID
  AND rp.demo_dataset_id = @DATASET_ID;

/* CNT-09: initiatives demo count = 2 */
SELECT
  'CNT-09 demo_initiatives_count' AS check_name,
  COUNT(*) AS result_value,
  2 AS expected_value,
  CASE WHEN COUNT(*) = 2 THEN 'PASS' ELSE 'FAIL' END AS result
FROM initiatives
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-10: tasks demo count = 3 */
SELECT
  'CNT-10 demo_tasks_count' AS check_name,
  COUNT(*) AS result_value,
  3 AS expected_value,
  CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END AS result
FROM tasks
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-11: allocations demo count = 2 */
SELECT
  'CNT-11 demo_allocations_count' AS check_name,
  COUNT(*) AS result_value,
  2 AS expected_value,
  CASE WHEN COUNT(*) = 2 THEN 'PASS' ELSE 'FAIL' END AS result
FROM allocations
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-12: finance_transactions demo count = 3 */
SELECT
  'CNT-12 demo_finance_transactions_count' AS check_name,
  COUNT(*) AS result_value,
  3 AS expected_value,
  CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END AS result
FROM finance_transactions
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-13: attachments demo count = 2 */
SELECT
  'CNT-13 demo_attachments_count' AS check_name,
  COUNT(*) AS result_value,
  2 AS expected_value,
  CASE WHEN COUNT(*) = 2 THEN 'PASS' ELSE 'FAIL' END AS result
FROM attachments
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-14: event_log demo count = 3 */
SELECT
  'CNT-14 demo_event_log_count' AS check_name,
  COUNT(*) AS result_value,
  3 AS expected_value,
  CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END AS result
FROM event_log
WHERE demo_dataset_id = @DATASET_ID;

/* CNT-15: audit_log demo count = 2 */
SELECT
  'CNT-15 demo_audit_log_count' AS check_name,
  COUNT(*) AS result_value,
  2 AS expected_value,
  CASE WHEN COUNT(*) = 2 THEN 'PASS' ELSE 'FAIL' END AS result
FROM audit_log
WHERE demo_dataset_id = @DATASET_ID;

-- ============================================================
-- C) HASH + BALANCE (DATASET)
-- ============================================================

/* HASH-01: demo users hash exact match */
SELECT
  'HASH-01 demo_users_hash_exact' AS check_name,
  SUM(CASE WHEN password_hash = @EXPECTED_HASH THEN 1 ELSE 0 END) AS hash_match_count,
  COUNT(*) AS expected_value,
  CASE
    WHEN COUNT(*) > 0 AND SUM(CASE WHEN password_hash = @EXPECTED_HASH THEN 1 ELSE 0 END) = COUNT(*)
    THEN 'PASS' ELSE 'FAIL'
  END AS result
FROM users
WHERE demo_dataset_id = @DATASET_ID;

/* BAL-01: allocations balanced */
SELECT
  'BAL-01 allocations_balanced' AS check_name,
  SUM(
    CASE
      WHEN ABS(
        COALESCE(allocated_amount,0) - (
          COALESCE(spent_amount,0) +
          COALESCE(committed_amount,0) +
          COALESCE(available_amount,0)
        )
      ) < @MONEY_TOLERANCE
      THEN 1 ELSE 0
    END
  ) AS result_value,
  COUNT(*) AS expected_value,
  CASE
    WHEN COUNT(*) > 0 AND
         SUM(
           CASE
             WHEN ABS(
               COALESCE(allocated_amount,0) - (
                 COALESCE(spent_amount,0) +
                 COALESCE(committed_amount,0) +
                 COALESCE(available_amount,0)
               )
             ) < @MONEY_TOLERANCE
             THEN 1 ELSE 0
           END
         ) = COUNT(*)
    THEN 'PASS' ELSE 'FAIL'
  END AS result
FROM allocations
WHERE demo_dataset_id = @DATASET_ID;

-- ============================================================
-- D) RBAC DUPLICATION RISK (DATASET)
-- ============================================================

/* RBAC-01: duplicates for GLOBAL scope_value NULL */
SELECT
  'RBAC-01 duplicate_global_role_permissions_null_scope_value' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM (
  SELECT rp.role_id, rp.permission_id
  FROM role_permissions rp
  WHERE rp.scope_type = 'GLOBAL'
    AND rp.scope_value IS NULL
  GROUP BY rp.role_id, rp.permission_id
  HAVING COUNT(*) > 1
) x;

SELECT '=== ACCEPTANCE ADDENDUM | END ===' AS banner;
