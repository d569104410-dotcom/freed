# FREED 2026 — Claude Build Pack (Prepared)
## What’s inside
- 01_ssot_batch1/: Batch 1 SSOT Freeze SQL (`install/schema.mysql.sql`, `install/seed.mysql.sql`)
- 02_session3_gatekeeper/: Session 3 Gatekeeper SQL pack (B1..B4 + ALL) + FREEZE record
- 03_session3_exec_pack/: Execution wrappers (Bash/PowerShell/CMD) + parsers + quick runbook
- 04_production_docs/: Freed production documentation & prompt pack (scope for Batch 2/3/4 + build guidance)
- 05_runbooks/: Master Session 3 runbook

## Critical invariants (do not change)
- Batch 1 schema is DDL-only; FKs are defined at end.
- Batch 1 seed is INSERT-only; Demo hash = Demo@123 bcrypt:
  $2b$10$yKfK89/06PEobiIllvmRW.YxOnlfkGxDpSh4KrQHGbe6F6q8GHOUS
- Demo dataset id: DEMO_2026
- Gatekeeper: any FAIL => batch FAIL.

## Suggested directory mapping (recommended)
Copy these files into your repo as:
- install/schema.mysql.sql  (from 01_ssot_batch1/install/schema.mysql.sql)
- install/seed.mysql.sql    (from 01_ssot_batch1/install/seed.mysql.sql)
- gatekeeper/session3/*     (from 02_session3_gatekeeper/*)
- ops/session3/*            (from 03_session3_exec_pack/*)
- docs/*                    (from 04_production_docs/* and 05_runbooks/*)

