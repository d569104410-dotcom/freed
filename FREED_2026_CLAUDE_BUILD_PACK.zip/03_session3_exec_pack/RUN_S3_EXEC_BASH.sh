#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# RUN_S3_EXEC_BASH.sh
# Session 3 (Gatekeeper) | DEMO_2026 | B1->B4 (ALL)
# Notes:
# - Do NOT edit Gatekeeper SQL scripts during execution.
# - Any change => Fix Attempt AFTER saving the log.
# ============================================================

# ---- REQUIRED CONFIG (edit these) ----
HOST="<HOST>"
PORT="<PORT>"
USER="<USER>"
DB="<DB_NAME>"
ENV_NAME="<ENV_NAME>"
OPERATOR="<NAME>"

# ---- OPTIONAL CONFIG ----
SCRIPT="RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql"
PARSER="parse_gatekeeper_log.py"   # expects to print a [RUN_RESULT] line (recommended)
PYTHON_BIN="${PYTHON_BIN:-python3}" # override if needed: PYTHON_BIN=python3 ./RUN_S3_EXEC_BASH.sh

# ---- RUNTIME ----
TS="$(date +%F_%H%M%S)"
START="$(date +'%F %T')"
LOG="RESULT_GATEKEEPER_ALL_DEMO_2026_${TS}.log"

# --- LOG DIRECTORY (safe patch: keeps existing filename) ---
LOG_DIR="${LOG_DIR:-logs/gatekeeper}"
mkdir -p "$LOG_DIR"

# If LOG_FILE is used
if [ "${LOG_FILE-}" != "" ]; then
  LOG_FILE="$LOG_DIR/$(basename "$LOG_FILE")"
fi

# If LOG is used
if [ "${LOG-}" != "" ]; then
  LOG="$LOG_DIR/$(basename "$LOG")"
fi

echo "[RUN_META] env=${ENV_NAME} | host=${HOST} | db=${DB} | pack=Session3_B1-B4 | script=${SCRIPT} | started_at=${START} | operator=${OPERATOR}" | tee "${LOG}"

# Run Gatekeeper pack (stdout+stderr to log)
mysql --default-character-set=utf8mb4 \
  -h "${HOST}" -P "${PORT}" -u "${USER}" -p "${DB}" \
  --verbose --show-warnings \
  < "${SCRIPT}" 2>&1 | tee -a "${LOG}" >/dev/null

# Parse log -> append RUN_RESULT
if [[ -f "${PARSER}" ]]; then
  "${PYTHON_BIN}" "${PARSER}" "${LOG}" 2>&1 | tee -a "${LOG}" >/dev/null
else
  echo "[RUN_RESULT] verdict=UNKNOWN | failed_checks=UNKNOWN | log_file=${LOG} | notes=parser_missing:${PARSER}" | tee -a "${LOG}"
fi

END="$(date +'%F %T')"
echo "[RUN_END] finished_at=${END} | log_file=${LOG}" | tee -a "${LOG}"

echo "[TRIAGE_NOTE] Any FAIL => FAIL. Focus: CHK-10/11/12/13/14 (Data), CHK-20..28 (Integrity), CHK-30/31 (Recon)." | tee -a "${LOG}"
echo "[DONE] log_file=${LOG}"
