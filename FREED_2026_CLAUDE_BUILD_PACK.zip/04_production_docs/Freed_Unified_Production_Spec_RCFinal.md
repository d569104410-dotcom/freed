# Freed — وثيقة موحّدة شاملة للإصدار الإنتاجي RCFinal (MySQL افتراضي + PostgreSQL اختياري)

> هذه الوثيقة تجمع المتطلبات الثابتة (Non‑Negotiables) + البنية + وحدات النظام + قواعد البيانات + الأمن + الهوية البصرية (4 Themes) + بيانات العرض + ضوابط الجودة والإطلاق، لتكون مرجعًا واحدًا “لا يقبل الصدفة”.

---

## 1) الهدف والمنتج

### 1.1 رسالة المنتج
نظام “Freed” هو منصة تشغيل وإدارة مبادرات لجمعيات/جهات، يدير: التخطيط والتنفيذ، فرق المبادرات، المهام والأدلة، التمويل والحركات، المتبرعين/المستقطعين، التنبيهات والقنوات (SMS/WhatsApp)، التقارير والطباعة والتصدير، مع صلاحيات مرنة وإدارة كاملة من الواجهة.

### 1.2 نموذج التسليم
- **Single‑tenant**: كل جهة = تثبيت مستقل + قاعدة بيانات مستقلة.
- **cPanel**: حزمة ZIP واحدة تُرفع إلى `public_html/freed/` وتعمل دون SSH/CLI.
- تثبيت عبر صفحة Installer واحدة.

---

## 2) ثوابت غير قابلة للتفاوض (Non‑Negotiables)

### 2.1 سياسة الصلاحيات RBAC المرنة (3 طبقات)
النظام يعتمد 3 طبقات: **Role Presets** + **Scope** + **User Overrides**【321:0†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L1-L6】.

- **Permission Registry**: كل زر/إجراء يجب أن يكون له Permission Key ثابت【321:0†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L7-L30】.
- **Scope Model**: GLOBAL/DEPARTMENT/INITIATIVE/SELF【321:0†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L31-L38】.
- **Overrides**: Allow/Deny per‑user، والقاعدة الحاكمة: **Deny يغلب Allow دائمًا**【321:0†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L39-L45】.
- **UI Enforcement**: كل زر/إجراء يمر: Permission Key → Scope Check → Override Resolution (Deny wins)【321:3†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L3-L8】.

### 2.2 فريق المبادرة (وليس مالك واحد)
المبادرة تُوزّع على **فريق متعدد** داخل المبادرة【321:0†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L48-L59】، مع أدوار (Leader/Co‑Lead/Member/Viewer).

### 2.3 قاعدة بيانات ثنائية المسار (DB Dual‑Path)
- المسار الافتراضي: **MySQL**.
- PostgreSQL **اختياري متقدم** دون تغيير منطق الأعمال【321:4†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L13-L18】.
- التبديل عبر طبقة Repository + migrations منفصلة لكل محرك【321:4†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L15-L18】.
- سياسة تحديث/رجوع: Snapshot قبل التحديث + Rollback عند الفشل دون المساس بالبيانات الأساسية【321:4†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L20-L24】.

### 2.4 SMS مدمج من البداية
SMS قناة تنبيهات ضمن Notifications Engine من بداية الإصدار【321:3†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L31-L33】.

### 2.5 التقارير والطباعة والتصدير
مركز تقارير وطباعة يدعم A4 Portrait/Landscape + Preview + تصدير PDF/Excel/Word/CSV【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L3-L10】.

---

## 3) بنية النظام (Architecture)

### 3.1 هيكل التسليم على cPanel
```
public_html/freed/
  .htaccess
  /app        # واجهة SPA Vanilla (Static)
  /api        # PHP Router + Endpoints + Libs
  /install    # One-step installer + schemas + patches + seeds
  /storage    # writable: logs / backups / locks / exports
```

### 3.2 فلسفة التنفيذ
- **MySQL-first**: Installer يثبت MySQL دائمًا.
- PostgreSQL يظهر كـ **Advanced** (زر ثانوي) بعد نجاح “تحقق من الاتصال” بـ MySQL، وعند فشل PG يعود إلى MySQL دون تعطيل.
- لا مكتبات خارجية، لا CDN، لا خطوط خارجية (system font stack).

---

## 4) وحدات النظام (Screens / Modules)

> المرجع: QuickDevIndex/Wireframes (شاشات متعددة). أمثلة مهمة:
- Reports & Print Center【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L3-L10】
- Notifications Center【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L27-L35】
- RBAC Studio【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L40-L41】

### 4.1 Dashboard حسب الدور
- KPI Cards + Charts + Actions (قراءة خلال 5 ثوان).
- تنبيهات حرجة/مهمة + روابط مباشرة (فتح مهمة/إرسال SMS/واتساب).

### 4.2 Initiatives
- Grid View + Table View (حسب المواصفات).
- Initiative Details (Initiative 360 / XL) بتبويبات (10) + Nested Modal.
- فريق المبادرة + مهام + أدلة + اعتمادات.

### 4.3 Employees / Executive Office
- “مهامي/تقييماتي/تعثراتي/فرقي/جدولي”【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L15-L22】.
- النجوم/التقييم محسوب من الالتزام + الأدلة + المواعيد【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L20-L22】.

### 4.4 Notifications + SMS Center
- مركز تنبيهات مع Actions (فتح/تواصل/إرسال SMS/واتساب)【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L27-L35】.
- SMS Provider قابل للاستبدال (Mock provider + real provider لاحقًا).

### 4.5 Reports & Print Center
- A4 + Portrait/Landscape + Preview + Export (PDF/Excel/Word/CSV)【321:1†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L3-L10】.
- Print defaults من DB (هوامش/اتجاه/مقاس) + مركز/هوامش مضبوط.

### 4.6 Import/Export
- Export CSV (UTF‑8 BOM) + مسار Excel‑compatible.
- Import CSV + Dry‑run + تقرير أخطاء row‑by‑row + Audit.

### 4.7 Settings
- Feature flags + إعدادات الطباعة + إعدادات SMS + إدارة RBAC من الواجهة.
- زر “Remove Demo Data” (system_admin فقط، تأكيد مزدوج + Audit).

---

## 5) الهوية البصرية (4 Themes) — آخر تحديث

### 5.1 مبادئ الهوية
وضوح هرمي عالي، بطاقات غنية، KPIs بارزة، حالات نجاح/تحذير/خطر، ثبات الأنماط بين الشاشات【321:8†Freed_RCFinal_Master_MySQL_PostgreSQL_Full_Spec_With_ASCII_QuickDevIndex.md†L1-L8】.

### 5.2 Theme Gallery (مرئية للجميع)
4 ثيمات Token‑based:
- notionish
- asanaish
- mondayish
- arabicSignature

**اللغة:** كل الواجهة عربية RTL، والأرقام/الاختصارات الشائعة فقط بالإنجليزية (KPI/ID/CSV/XLSX/A4).

**تخزين الثيم:**
- Default للجمعية: settings
- تفضيل شخصي: user_settings (يعلو على الافتراضي)

---

## 6) قاعدة البيانات (High-Level Model)

> الهدف: نموذج علائقي قابل للتقارير والتوسع، مع dual-path (MySQL default + PG optional).

### 6.1 جداول أساسية (Minimum Production)
- Identity & Auth: users, roles, permissions, role_permissions, user_permission_overrides (allow/deny + scope)
- Initiatives: initiatives, initiative_team, initiative_team_members
- Tasks & Evidence: tasks, task_evidence_rules, task_evidence_items, approvals
- Attachments: attachments (entity_type/entity_id/uploaded_by/…)
- Notifications: notifications, notification_channels, sms_outbox, event_logs【321:3†Freed_System_Full_Details_With_ASCII_Wireframes_RCFinal.md†L16-L23】
- Finance: finance_transactions, allocations (multi‑beneficiary optional linkage)
- Reports/Print: print_settings, report_exports
- Import/Export: import_jobs, import_job_rows, import_errors
- Audit: audit_log
- Settings: settings, feature_flags, user_settings
- Ops: backups, ssot_snapshots

### 6.2 قواعد بيانات حاكمة (DB Invariants)
- Deny wins دائمًا في Overrides (منطق تطبيق).
- مهمة واحدة لموظف واحد (task.assigned_to_user_id NOT NULL) — مع إمكانية رؤية عدة أعضاء عبر initiative_team.
- default واحد فقط لكل (user_id, module) في saved_views.
- كل تعديل حساس يكتب audit_log.

---

## 7) الأمن (Security P0)

- Password hashing (Argon2id/Bcrypt) + PIN 4 digits hashed+salt.
- Lockout: 5 محاولات/10 دقائق + Rate limiting.
- RBAC enforcement في API + UI gating.
- /admin/* masked as 404 لغير المصرح.
- Security headers في `.htaccess`.
- كل Create/Update/Delete/Import/Export/Settings change → audit_log.

---

## 8) بيانات العرض (Seed Demo) — شاملة وقابلة للإزالة

### 8.1 Seed “Wow Demo”
- موظفين + مبادرات + فريق مبادرة + مهام + أدلة + حركات مالية + متبرعين/مستقطعين + تنبيهات + رسائل SMS في Outbox (Mock) + تقارير/طباعة.

### 8.2 إزالة الديمو (Production-safe)
- زر داخل Settings (system_admin):
  - Confirm 1: checkbox + شرح
  - Confirm 2: إدخال كلمة “DELETE”
  - يسجل audit_log ويزيل كل بيانات demo بعلامة demo_marker أو جدول mapping.

---

## 9) ضوابط الجودة والاختبارات (Quality Gates)

### 9.1 تغطية E2E (أمثلة)
- إنشاء مبادرة + إضافة فريق + مهام + أدلة + اعتماد.
- دفعة مستقطع + تعثر شهرين + التزام 6 أشهر → تنبيه + SMS Outbox.
- توزيع مالي متعدد + تقارير + تصدير CSV.
- RBAC: منع زر/إجراء بدون صلاحية + Deny override يتغلب.
- Print center: A4 + margins/orientation + preview + تصدير.

### 9.2 أدلة التسليم (Release Evidence)
- Test plan + 40 Acceptance Criteria
- 12 curl scripts + expected JSON
- Backup/Restore drill (على shared hosting)
- Go/No‑Go checklist

---

## 10) مخرجات التسليم (Delivery)

### 10.1 ما يجب أن يُسلّم في كل إصدار
- ZIP structure جاهز للرفع
- Installer + schemas + patches + seed
- API + UI working
- Preview offline artifacts داخل `/app/preview/`
- وثيقة Delivery.md: coverage + install steps + tests + known limitations + rollback

---

# ملحق A — تعريف Saved Views (مبادرات) — (شخصي)
- view_name يدعم Emoji (utf8mb4)
- icon_key + مكتبة icons (ملونة في القائمة/الاختيار فقط، أحادية داخل الجدول بلون النص الثانوي حسب الثيم)
- columns_visible + columns_order (+ sort/widths/search/filters اختيارية)
- default واحد فقط لكل مستخدم للمبادرات

---

# ملحق B — نص الفوتر الثابت (Login Footer)
يُثبت حرفيًا حسب ما في الوثائق التنفيذية (لا يُغيّر).
