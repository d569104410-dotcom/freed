# Freed — Review & Quality Scorecard (Production-Ready 100%)

## 1) Architecture & Delivery (20)
- [ ] ZIP يعمل على cPanel بدون SSH/CLI
- [ ] Installer صفحة واحدة + health checks + install.lock
- [ ] MySQL-first + Advanced PG optional fallback
- [ ] structure ثابتة (/app,/api,/install,/storage,/.htaccess)

## 2) Security (20)
- [ ] Password hash + PIN 4 digits hash+salt
- [ ] lockout 5/10min + rate limit
- [ ] RBAC: registry + scope + overrides (deny wins)
- [ ] admin masking 404
- [ ] audit_log لكل الحسّاس

## 3) Data Model & Integrity (15)
- [ ] schema.mysql.sql كامل + indexes + constraints
- [ ] seed آمن + demo_marker + remove demo (settings only)
- [ ] import/export jobs/errors logging
- [ ] print settings persisted

## 4) UI/UX & Identity (25)
- [ ] Glass Header + tagline “نظام إدارة المبادرات والمتابعة”
- [ ] Glass Login Brand + roles selection
- [ ] Hero cards (الرؤية/الرسالة) + values chips
- [ ] 4 themes + theme gallery for all + light/dark + RTL
- [ ] Initiative 360 tabs 10 تعمل + sticky + nested modal

## 5) QA Evidence (20)
- [ ] Coverage matrix
- [ ] 40 acceptance criteria
- [ ] 12 curl scripts
- [ ] Backup/restore drill
- [ ] Go/No-Go checklist

### Passing bar
- Minimum: 90/100 و(0 Critical, 0 High) في نتائج الاختبار.
