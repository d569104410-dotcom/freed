# FA003_PRECHECK_COMMANDS.md

## الهدف
فحوصات ما قبل التشغيل لـ **FA-003 (Formatting Only Patch)** للتأكد أن التغيير:
- **تنسيقي فقط** (Headers/Banner/Sections/Verdict Note)
- **بدون أي Logic-change**
- وبدون تغيير **أسماء الفحوص** (CHK-XX / CHK-XX_DIAG)

---

## القيم الافتراضية (موصى بها)
> إذا كان FA-003 عبارة عن آخر commit فقط:

- BEFORE_REF = `HEAD~1`
- AFTER_REF  = `HEAD`

> إذا تستخدمون Tag:
- BEFORE_REF = `<TAG_BEFORE>`
- AFTER_REF  = `<TAG_AFTER>`

---

## 1) Linux / macOS (git + diff)

### A) مقارنة أسماء الفحوص (CHK/DIAG) قبل/بعد — الأهم
> يضمن عدم تغيّر رموز CHK-XX و CHK-XX_DIAG (مهم للـ parsing والمقارنة مع logs السابقة)

```bash
BEFORE_REF="HEAD~1"
AFTER_REF="HEAD"

# BEFORE (من git)
git show "${BEFORE_REF}:RUN_S3_GATEKEEPER_B1_DEMO_2026.sql" | egrep -o "CHK-[0-9]{2}(_DIAG)?" | sort -u > /tmp/chk_before_b1.txt
git show "${BEFORE_REF}:RUN_S3_GATEKEEPER_B3_DEMO_2026.sql" | egrep -o "CHK-[0-9]{2}(_DIAG)?" | sort -u > /tmp/chk_before_b3.txt
git show "${BEFORE_REF}:RUN_S3_GATEKEEPER_B4_DEMO_2026.sql" | egrep -o "CHK-[0-9]{2}(_DIAG)?" | sort -u > /tmp/chk_before_b4.txt

# AFTER (من ملفات العمل الحالية)
egrep -o "CHK-[0-9]{2}(_DIAG)?" RUN_S3_GATEKEEPER_B1_DEMO_2026.sql | sort -u > /tmp/chk_after_b1.txt
egrep -o "CHK-[0-9]{2}(_DIAG)?" RUN_S3_GATEKEEPER_B3_DEMO_2026.sql | sort -u > /tmp/chk_after_b3.txt
egrep -o "CHK-[0-9]{2}(_DIAG)?" RUN_S3_GATEKEEPER_B4_DEMO_2026.sql | sort -u > /tmp/chk_after_b4.txt

# DIFF (يجب أن تكون فارغة)
diff -u /tmp/chk_before_b1.txt /tmp/chk_after_b1.txt
diff -u /tmp/chk_before_b3.txt /tmp/chk_after_b3.txt
diff -u /tmp/chk_before_b4.txt /tmp/chk_after_b4.txt

Expected: لا يوجد أي output من diff.
```

### B) تأكيد أن التغييرات تنسيق فقط (diff سريع)

يجب ألا يظهر أي تعديل داخل JOIN/WHERE/GROUP BY/Expressions داخل بلوكات CHECKS/DIAGNOSTICS.

```bash
BEFORE_REF="HEAD~1"
AFTER_REF="HEAD"

git diff "${BEFORE_REF}..${AFTER_REF}" -- \
  RUN_S3_GATEKEEPER_B1_DEMO_2026.sql \
  RUN_S3_GATEKEEPER_B3_DEMO_2026.sql \
  RUN_S3_GATEKEEPER_B4_DEMO_2026.sql
```

Expected: تغييرات Headers/Banner/Section titles/Verdict note فقط.

## 2) Windows PowerShell

### A) مقارنة أسماء الفحوص (CHK/DIAG) قبل/بعد
```powershell
$BEFORE_REF = "HEAD~1"
$AFTER_REF  = "HEAD"

function Get-ChkListFromGit([string]$ref, [string]$file) {
  $spec = "{0}:{1}" -f $ref, $file
  (git show $spec) |
    Select-String -AllMatches "CHK-\d{2}(_DIAG)?" |
    ForEach-Object { $_.Matches.Value } |
    Sort-Object -Unique
}

function Get-ChkListFromFile([string]$file) {
  Get-Content $file |
    Select-String -AllMatches "CHK-\d{2}(_DIAG)?" |
    ForEach-Object { $_.Matches.Value } |
    Sort-Object -Unique
}

# BEFORE
$beforeB1 = Get-ChkListFromGit $BEFORE_REF "RUN_S3_GATEKEEPER_B1_DEMO_2026.sql"
$beforeB3 = Get-ChkListFromGit $BEFORE_REF "RUN_S3_GATEKEEPER_B3_DEMO_2026.sql"
$beforeB4 = Get-ChkListFromGit $BEFORE_REF "RUN_S3_GATEKEEPER_B4_DEMO_2026.sql"

# AFTER
$afterB1 = Get-ChkListFromFile "RUN_S3_GATEKEEPER_B1_DEMO_2026.sql"
$afterB3 = Get-ChkListFromFile "RUN_S3_GATEKEEPER_B3_DEMO_2026.sql"
$afterB4 = Get-ChkListFromFile "RUN_S3_GATEKEEPER_B4_DEMO_2026.sql"

# DIFF (يجب ألا يظهر شيء)
Compare-Object $beforeB1 $afterB1
Compare-Object $beforeB3 $afterB3
Compare-Object $beforeB4 $afterB4
```

Expected: لا يظهر أي اختلافات من Compare-Object.

### B) diff سريع للتأكد أن التغييرات تنسيق فقط
```powershell
$BEFORE_REF = "HEAD~1"
$AFTER_REF  = "HEAD"

git diff "$BEFORE_REF..$AFTER_REF" -- `
  RUN_S3_GATEKEEPER_B1_DEMO_2026.sql `
  RUN_S3_GATEKEEPER_B3_DEMO_2026.sql `
  RUN_S3_GATEKEEPER_B4_DEMO_2026.sql
```

## 3) قاعدة القرار (Decision Rule)

- إذا اختلفت قوائم CHK/CHK_DIAG ⇒ رفض FA-003 (ليس Formatting only).
- إذا ظهر تعديل داخل JOIN/WHERE/GROUP BY/Expressions ⇒ رفض FA-003 (Logic change).
- إذا كل شيء مطابق ⇒ اعتماد FA-003 ثم نفّذ Gatekeeper pack واحفظ log.
