-- ============================================================
-- RUN_S3_GATEKEEPER_B1_DEMO_2026.sql
-- SESSION 3 (Gatekeeper) | Batch 1/4 | SCHEMA Checks (SAFE)
-- Scope: GLOBAL (information_schema only)
-- Notes:
--   - Uses information_schema ONLY
--   - This batch must be run first (prerequisite for B2/B3/B4)
-- ============================================================

-- ----------------------------
-- RUNTIME VARIABLES
-- ----------------------------
SET @DATASET_ID := 'DEMO_2026';

-- ----------------------------
-- BANNER
-- ----------------------------
SELECT CONCAT(
  '=== SESSION 3 (Gatekeeper) | Batch 1/4 (SCHEMA) | SCOPE=GLOBAL | DATASET=', @DATASET_ID,
  ' ==='
) AS session_banner;

-- ============================================================
-- CHECKS (PASS/FAIL rows)
-- ============================================================

SELECT
  'CHK-01 table_exists_allocations' AS check_name,
  (SELECT COUNT(*) FROM information_schema.tables
   WHERE table_schema = DATABASE() AND table_name = 'allocations') AS result_value,
  1 AS expected_value,
  CASE WHEN (SELECT COUNT(*) FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_name = 'allocations') = 1
       THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-02 table_must_not_exist_finance_allocations' AS check_name,
  (SELECT COUNT(*) FROM information_schema.tables
   WHERE table_schema = DATABASE() AND table_name = 'finance_allocations') AS result_value,
  0 AS expected_value,
  CASE WHEN (SELECT COUNT(*) FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_name = 'finance_allocations') = 0
       THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-03 required_tables_count' AS check_name,
  (SELECT COUNT(*) FROM information_schema.tables
   WHERE table_schema = DATABASE()
     AND table_name IN (
       'organizations','departments','roles','permissions','role_permissions','users',
       'initiatives','tasks','finance_transactions','allocations','budget_lines','vendors',
       'attachments','event_log','audit_log'
     )) AS result_value,
  15 AS expected_value,
  CASE WHEN (SELECT COUNT(*) FROM information_schema.tables
             WHERE table_schema = DATABASE()
               AND table_name IN (
                 'organizations','departments','roles','permissions','role_permissions','users',
                 'initiatives','tasks','finance_transactions','allocations','budget_lines','vendors',
                 'attachments','event_log','audit_log'
               )) = 15
       THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-04 demo_columns_exist__organizations' AS check_name,
  (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='organizations') AS result_value,
  1 AS expected_value,
  CASE WHEN (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='organizations') = 1
  THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-05 demo_columns_exist__users' AS check_name,
  (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='users') AS result_value,
  1 AS expected_value,
  CASE WHEN (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='users') = 1
  THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-06 demo_columns_exist__allocations' AS check_name,
  (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='allocations') AS result_value,
  1 AS expected_value,
  CASE WHEN (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='allocations') = 1
  THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-07 demo_columns_exist__finance_transactions' AS check_name,
  (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='finance_transactions') AS result_value,
  1 AS expected_value,
  CASE WHEN (SELECT
     CASE
       WHEN SUM(CASE WHEN column_name='demo_marker' THEN 1 ELSE 0 END)=1
        AND SUM(CASE WHEN column_name='demo_dataset_id' THEN 1 ELSE 0 END)=1
       THEN 1 ELSE 0 END
   FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name='finance_transactions') = 1
  THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-08 finance_transactions_has_column_amount' AS check_name,
  COALESCE((SELECT COUNT(*) FROM information_schema.columns
            WHERE table_schema=DATABASE() AND table_name='finance_transactions' AND column_name='amount'),0) AS result_value,
  1 AS expected_value,
  CASE WHEN COALESCE((SELECT COUNT(*) FROM information_schema.columns
                      WHERE table_schema=DATABASE() AND table_name='finance_transactions' AND column_name='amount'),0)=1
       THEN 'PASS' ELSE 'FAIL' END AS result
UNION ALL
SELECT
  'CHK-09 finance_transactions_has_column_exchange_rate_and_amount_sar' AS check_name,
  COALESCE((SELECT
              SUM(CASE WHEN column_name IN ('exchange_rate','amount_sar') THEN 1 ELSE 0 END)
            FROM information_schema.columns
            WHERE table_schema=DATABASE() AND table_name='finance_transactions'
              AND column_name IN ('exchange_rate','amount_sar')),0) AS result_value,
  2 AS expected_value,
  CASE WHEN COALESCE((SELECT
              SUM(CASE WHEN column_name IN ('exchange_rate','amount_sar') THEN 1 ELSE 0 END)
            FROM information_schema.columns
            WHERE table_schema=DATABASE() AND table_name='finance_transactions'
              AND column_name IN ('exchange_rate','amount_sar')),0)=2
       THEN 'PASS' ELSE 'FAIL' END AS result;

-- ============================================================
-- FINAL VERDICT NOTE
-- ============================================================
SELECT
  'BATCH_VERDICT_NOTE' AS note,
  'If any check result = FAIL, then batch verdict is FAIL; otherwise PASS.' AS rule;
