# Session 3 Quick Runbook (Gatekeeper) — v1.0

## الهدف
تشغيل Session 3 Gatekeeper (B1→B4) على قاعدة البيانات، حفظ السجل (log)، استخراج PASS/FAIL وقائمة CHK الفاشلة تلقائيًا، ثم توثيق النتيجة بصيغة موحدة.

## 0) المتطلبات قبل التشغيل
- RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql
- RUN_S3_GATEKEEPER_B1_DEMO_2026.sql
- RUN_S3_GATEKEEPER_B2_DEMO_2026.sql
- RUN_S3_GATEKEEPER_B3_DEMO_2026.sql
- RUN_S3_GATEKEEPER_B4_DEMO_2026.sql
- بيانات الاتصال: `<HOST> <PORT> <USER> <DB_NAME>`
- نطاق الديمو: `DATASET_ID = 'DEMO_2026'`

## 1) تشغيل Gatekeeper وحفظ log

### Linux / macOS (Bash)
```bash
LOG="RESULT_GATEKEEPER_ALL_DEMO_2026_$(date +%F_%H%M%S).log"

mysql --default-character-set=utf8mb4 -h <HOST> -P <PORT> -u <USER> -p <DB_NAME> \
  --verbose --show-warnings \
  < RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | tee "$LOG" >/dev/null

echo "[RUN_META] env=<ENV_NAME> | host=<HOST> | db=<DB_NAME> | pack=Session3_B1-B4 | script=RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | started_at=$(date +'%F %T') | operator=<NAME>" >> "$LOG"
```

### Windows PowerShell
```powershell
$ts = Get-Date -Format "yyyy-MM-dd_HHmmss"
$log = "RESULT_GATEKEEPER_ALL_DEMO_2026_$ts.log"

mysql --default-character-set=utf8mb4 -h <HOST> -P <PORT> -u <USER> -p <DB_NAME> --verbose --show-warnings `
  < RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | Tee-Object -FilePath $log

Add-Content $log "[RUN_META] env=<ENV_NAME> | host=<HOST> | db=<DB_NAME> | pack=Session3_B1-B4 | script=RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | started_at=$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) | operator=<NAME>"
```

## 2) Parsing سريع للنتيجة

### Linux/macOS — awk
```bash
awk '
  BEGIN { fails_count=0 }
  /CHK-[0-9][0-9]/ && /FAIL/ {
    match($0, /(CHK-[0-9][0-9])/, m)
    if (m[1] != "") { fails[m[1]]=1 }
  }
  END {
    for (k in fails) { fails_list=(fails_list==""?k:fails_list","k); fails_count++ }
    if (fails_count==0) print "[RUN_RESULT] verdict=PASS | failed_checks=NONE"
    else print "[RUN_RESULT] verdict=FAIL | failed_checks="fails_list
  }
' "$LOG"
```

### Python (عابر للبيئات)
```bash
python3 parse_gatekeeper_log.py "$LOG"
```

### Windows PowerShell
```powershell
$failed = Select-String -Path $log -Pattern "CHK-\d{2}" | ForEach-Object {
  if ($_.Line -match "(CHK-\d{2})" -and $_.Line -match "FAIL") { $Matches[1] }
} | Sort-Object -Unique

if (($failed | Measure-Object).Count -eq 0) {
  "[RUN_RESULT] verdict=PASS | failed_checks=NONE | log_file=$log"
} else {
  "[RUN_RESULT] verdict=FAIL | failed_checks=$($failed -join ',') | log_file=$log"
}
```

## 3) توثيق النتيجة داخل نفس ملف الـ log

### Bash
```bash
RESULT_LINE=$(python3 parse_gatekeeper_log.py "$LOG")
echo "$RESULT_LINE | finished_at=$(date +'%F %T') | notes=<SHORT_NOTE>" | tee -a "$LOG"
```

### PowerShell
```powershell
$resultLine = (python parse_gatekeeper_log.py $log)
Add-Content $log ($resultLine + " | finished_at=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " | notes=<SHORT_NOTE>")
```

## 4) قاعدة القرار
- إذا ظهر أي `FAIL` في أي `CHK-XX` ⇒ **Verdict = FAIL**
- إذا لا يوجد أي `FAIL` ⇒ **Verdict = PASS**
- عند FAIL: افتح الـ log وابحث عن `CHK-XX_DIAG`

## 5) أين نبحث عند الفشل (Fast Triage)
- `CHK-10/11/12/13/14`: مشاكل بيانات Demo/Bootstrap/Hash/Balance
- `CHK-20..28`: Orphans / Referential Integrity
- `CHK-30/31`: تواريخ/حسابات مالية (FX / amount_sar) — وقد تكون `SKIPPED__MISSING_COLUMNS`
