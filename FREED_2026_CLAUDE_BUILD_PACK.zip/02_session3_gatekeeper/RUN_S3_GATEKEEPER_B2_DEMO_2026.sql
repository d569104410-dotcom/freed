-- ============================================================
-- RUN_S3_GATEKEEPER_B2_DEMO_2026.sql
-- SESSION 3 (Gatekeeper) | Batch 2/4 | DATA Checks
-- Scope: DATASET = DEMO_2026 (except bootstrap checks which are GLOBAL by intent)
-- Notes:
--   - Diagnostics queries included and may return 0 rows when PASS
--   - Run after B1/4 Schema checks PASS for required tables/columns
-- ============================================================

SET @DATASET_ID := 'DEMO_2026';
SET @MONEY_TOLERANCE := 0.0001;
SET @EXPECTED_HASH := '$2b$10$yKfK89/06PEobiIllvmRW.YxOnlfkGxDpSh4KrQHGbe6F6q8GHOUS';

SELECT CONCAT(
  '=== SESSION 3 (Gatekeeper) | Batch 2/4 (DATA) | DATASET=', @DATASET_ID,
  ' | MONEY_TOL=', @MONEY_TOLERANCE,
  ' ==='
) AS session_banner;

-- ============================================================
-- CHECKS (PASS/FAIL rows)
-- ============================================================

/* CHK-10: permissions MUST NOT be demo (GLOBAL) */
SELECT
  'CHK-10 demo_permissions_must_be_zero' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM permissions
WHERE COALESCE(demo_marker,0)=1 OR demo_dataset_id=@DATASET_ID;

/* CHK-11: bootstrap role_permissions MUST NOT be demo (GLOBAL, bootstrap roles only) */
SELECT
  'CHK-11 demo_links_for_bootstrap_roles_must_be_zero' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
WHERE r.organization_id IS NULL
  AND (COALESCE(rp.demo_marker,0)=1 OR rp.demo_dataset_id=@DATASET_ID);

/* CHK-12: demo role_permissions count should be 7 (DATASET) */
SELECT
  'CHK-12 demo_links_for_demo_roles_expected_7' AS check_name,
  COUNT(*) AS result_value,
  7 AS expected_value,
  CASE WHEN COUNT(*) = 7 THEN 'PASS' ELSE 'FAIL' END AS result
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
WHERE r.demo_dataset_id=@DATASET_ID
  AND rp.demo_dataset_id=@DATASET_ID;

/* CHK-13: demo users hash must match EXACT expected hash (DATASET) */
SELECT
  'CHK-13 demo_users_hash_is_Demo@123' AS check_name,
  SUM(CASE WHEN password_hash = @EXPECTED_HASH THEN 1 ELSE 0 END) AS hash_match_count,
  COUNT(*) AS demo_users_total,
  CASE
    WHEN COUNT(*) > 0
     AND SUM(CASE WHEN password_hash = @EXPECTED_HASH THEN 1 ELSE 0 END) = COUNT(*)
    THEN 'PASS' ELSE 'FAIL'
  END AS result
FROM users
WHERE demo_dataset_id = @DATASET_ID;

/* CHK-14: allocations balanced (DATASET) with tolerance + COALESCE */
SELECT
  'CHK-14 allocations_balanced' AS check_name,
  SUM(
    CASE
      WHEN ABS(
        COALESCE(allocated_amount,0) - (
          COALESCE(spent_amount,0) + COALESCE(committed_amount,0) + COALESCE(available_amount,0)
        )
      ) < @MONEY_TOLERANCE THEN 1 ELSE 0
    END
  ) AS balanced_rows,
  COUNT(*) AS allocations_total,
  CASE
    WHEN COUNT(*) > 0 AND
         SUM(
           CASE
             WHEN ABS(
               COALESCE(allocated_amount,0) - (
                 COALESCE(spent_amount,0) + COALESCE(committed_amount,0) + COALESCE(available_amount,0)
               )
             ) < @MONEY_TOLERANCE THEN 1 ELSE 0
           END
         ) = COUNT(*)
    THEN 'PASS' ELSE 'FAIL'
  END AS result
FROM allocations
WHERE demo_dataset_id = @DATASET_ID;

-- ============================================================
-- DIAGNOSTICS (violations only; may return 0 rows when PASS)
-- ============================================================

/* CHK-10_DIAG: demo permissions found */
SELECT
  'CHK-10_DIAG demo_permissions_rows' AS diag_name,
  id, permission_key, module, action, demo_marker, demo_dataset_id
FROM permissions
WHERE COALESCE(demo_marker,0)=1 OR demo_dataset_id=@DATASET_ID
LIMIT 200;

/* CHK-11_DIAG: demo links found for bootstrap roles */
SELECT
  'CHK-11_DIAG demo_links_for_bootstrap_roles' AS diag_name,
  rp.id, rp.role_id, rp.permission_id, rp.demo_marker, rp.demo_dataset_id,
  r.slug AS role_slug, r.organization_id AS role_org_id
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
WHERE r.organization_id IS NULL
  AND (COALESCE(rp.demo_marker,0)=1 OR rp.demo_dataset_id=@DATASET_ID)
LIMIT 200;

/* CHK-12_DIAG: list demo links (helps if count != 7) */
SELECT
  'CHK-12_DIAG demo_links_for_demo_roles' AS diag_name,
  rp.id, rp.role_id, rp.permission_id, rp.demo_marker, rp.demo_dataset_id,
  r.slug AS role_slug
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
WHERE r.demo_dataset_id=@DATASET_ID
  AND rp.demo_dataset_id=@DATASET_ID
LIMIT 200;

/* CHK-13_DIAG: demo users hash mismatch or NULL */
SELECT
  'CHK-13_DIAG demo_users_hash_mismatch_or_null' AS diag_name,
  id, email, password_hash, demo_marker, demo_dataset_id
FROM users
WHERE demo_dataset_id=@DATASET_ID
  AND (password_hash IS NULL OR password_hash <> @EXPECTED_HASH)
LIMIT 200;

/* CHK-14_DIAG: allocations unbalanced rows */
SELECT
  'CHK-14_DIAG allocations_unbalanced_rows' AS diag_name,
  id,
  allocated_amount,
  spent_amount,
  committed_amount,
  available_amount,
  (COALESCE(spent_amount,0) + COALESCE(committed_amount,0) + COALESCE(available_amount,0)) AS computed_total,
  (COALESCE(allocated_amount,0) - (COALESCE(spent_amount,0) + COALESCE(committed_amount,0) + COALESCE(available_amount,0))) AS delta,
  demo_marker,
  demo_dataset_id
FROM allocations
WHERE demo_dataset_id=@DATASET_ID
  AND ABS(
    COALESCE(allocated_amount,0) - (
      COALESCE(spent_amount,0) + COALESCE(committed_amount,0) + COALESCE(available_amount,0)
    )
  ) >= @MONEY_TOLERANCE
ORDER BY ABS(
  COALESCE(allocated_amount,0) - (
    COALESCE(spent_amount,0) + COALESCE(committed_amount,0) + COALESCE(available_amount,0)
  )
) DESC
LIMIT 200;

-- ============================================================
-- FINAL VERDICT NOTE
-- ============================================================

SELECT
  'BATCH_VERDICT_NOTE' AS note,
  'If any check result = FAIL, then batch verdict is FAIL; otherwise PASS.' AS rule;
