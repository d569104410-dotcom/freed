-- ============================================================
-- RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql
-- Purpose: Run Session 3 Gatekeeper Pack in order (B1 -> B4)
-- Notes:
--   - Gatekeeper ONLY (no schema/seed)
--   - Assumes the 4 scripts are in the same directory, or use absolute paths
-- ============================================================

SELECT '=== RUN_S3_GATEKEEPER_ALL_DEMO_2026 | START ===' AS banner;

SOURCE RUN_S3_GATEKEEPER_B1_DEMO_2026.sql;
SOURCE RUN_S3_GATEKEEPER_B2_DEMO_2026.sql;
SOURCE RUN_S3_GATEKEEPER_B3_DEMO_2026.sql;
SOURCE RUN_S3_GATEKEEPER_B4_DEMO_2026.sql;

SELECT '=== RUN_S3_GATEKEEPER_ALL_DEMO_2026 | END ===' AS banner;
