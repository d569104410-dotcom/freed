import re
import sys
from pathlib import Path


def parse_log(path: Path):
    text = path.read_text(errors="ignore")
    chk_fail = set()
    for line in text.splitlines():
        if "CHK-" in line and "FAIL" in line:
            m = re.search(r"(CHK-\d{2})", line)
            if m:
                chk_fail.add(m.group(1))

    verdict = "PASS" if not chk_fail else "FAIL"
    failed_checks = "NONE" if verdict == "PASS" else ",".join(sorted(chk_fail))
    print(f"[RUN_RESULT] verdict={verdict} | failed_checks={failed_checks} | log_file={path.name}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python parse_gatekeeper_log.py <log_file>")
        sys.exit(2)
    parse_log(Path(sys.argv[1]))
