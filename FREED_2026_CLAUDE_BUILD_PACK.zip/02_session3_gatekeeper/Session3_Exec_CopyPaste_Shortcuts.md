# Session 3 Exec Shortcuts (Copy/Paste)

## Linux / macOS (Bash)
```bash
HOST="<HOST>"; PORT="<PORT>"; USER="<USER>"; DB="<DB_NAME>"; ENV="<ENV_NAME>"; OP="<NAME>"
TS="$(date +%F_%H%M%S)"; START="$(date +'%F %T')"
LOG="RESULT_GATEKEEPER_ALL_DEMO_2026_${TS}.log"
echo "[RUN_META] env=$ENV | host=$HOST | db=$DB | pack=Session3_B1-B4 | script=RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | started_at=$START | operator=$OP" | tee "$LOG"
mysql --default-character-set=utf8mb4 -h "$HOST" -P "$PORT" -u "$USER" -p "$DB" --verbose --show-warnings < RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | tee -a "$LOG" >/dev/null
python3 parse_gatekeeper_log.py "$LOG" | tee -a "$LOG"
echo "[RUN_RESULT_NOTE] Any FAIL => FAIL. Triage: CHK-10/11/12/13/14 (Data), CHK-20..28 (Integrity), CHK-30/31 (Recon)" | tee -a "$LOG"
echo "[DONE] log_file=$LOG"
```

## Windows PowerShell
```powershell
$HOST="<HOST>"; $PORT="<PORT>"; $USER="<USER>"; $DB="<DB_NAME>"; $ENV="<ENV_NAME>"; $OP="<NAME>"
$ts = Get-Date -Format "yyyy-MM-dd_HHmmss"; $start = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$log = "RESULT_GATEKEEPER_ALL_DEMO_2026_$ts.log"
"[RUN_META] env=$ENV | host=$HOST | db=$DB | pack=Session3_B1-B4 | script=RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | started_at=$start | operator=$OP" | Tee-Object -FilePath $log
mysql --default-character-set=utf8mb4 -h $HOST -P $PORT -u $USER -p $DB --verbose --show-warnings < RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql | Tee-Object -FilePath $log -Append
python parse_gatekeeper_log.py $log | Tee-Object -FilePath $log -Append
"[RUN_RESULT_NOTE] Any FAIL => FAIL. Triage: CHK-10/11/12/13/14 (Data), CHK-20..28 (Integrity), CHK-30/31 (Recon)" | Tee-Object -FilePath $log -Append
"[DONE] log_file=$log"
```

## Windows CMD
```bat
set HOST=<HOST> & set PORT=<PORT> & set USER=<USER> & set DB=<DB_NAME>
set LOG=RESULT_GATEKEEPER_ALL_DEMO_2026.log
mysql --default-character-set=utf8mb4 -h %HOST% -P %PORT% -u %USER% -p %DB% --verbose --show-warnings < RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql > %LOG%
python parse_gatekeeper_log.py %LOG% >> %LOG%
type %LOG%
```
