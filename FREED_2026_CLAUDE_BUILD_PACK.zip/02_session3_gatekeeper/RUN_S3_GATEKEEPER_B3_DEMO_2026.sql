-- ============================================================
-- RUN_S3_GATEKEEPER_B3_DEMO_2026.sql
-- SESSION 3 (Gatekeeper) | Batch 3/4 | INTEGRITY Checks
-- Scope: GLOBAL (orphans are integrity issues regardless of dataset)
-- Notes:
--   - Diagnostics queries included and may return 0 rows when PASS
--   - Run after B1 Schema PASS for referenced tables/columns
-- ============================================================

SET @DATASET_ID := 'DEMO_2026';

SELECT CONCAT('=== SESSION 3 (Gatekeeper) | Batch 3/4 (INTEGRITY) | DATASET=', @DATASET_ID, ' ===') AS session_banner;

-- ============================================================
-- CHECKS (PASS/FAIL rows)
-- ============================================================

/* CHK-20: users.role_id must reference roles.id (no orphans) */
SELECT
  'CHK-20 orphan_users_role_id__ref_roles_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM users u
LEFT JOIN roles r ON r.id = u.role_id
WHERE u.role_id IS NOT NULL
  AND r.id IS NULL;

/* CHK-21: users.department_id must reference departments.id (no orphans) */
SELECT
  'CHK-21 orphan_users_department_id__ref_departments_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM users u
LEFT JOIN departments d ON d.id = u.department_id
WHERE u.department_id IS NOT NULL
  AND d.id IS NULL;

/* CHK-22: departments.organization_id must reference organizations.id */
SELECT
  'CHK-22 orphan_departments_org_id__ref_organizations_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM departments d
LEFT JOIN organizations o ON o.id = d.organization_id
WHERE d.organization_id IS NOT NULL
  AND o.id IS NULL;

/* CHK-23: initiatives.owner_id must reference users.id (no orphans) */
SELECT
  'CHK-23 orphan_initiatives_owner_id__ref_users_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM initiatives i
LEFT JOIN users u ON u.id = i.owner_id
WHERE i.owner_id IS NOT NULL
  AND u.id IS NULL;

/* CHK-24: tasks.initiative_id must reference initiatives.id */
SELECT
  'CHK-24 orphan_tasks_initiative_id__ref_initiatives_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM tasks t
LEFT JOIN initiatives i ON i.id = t.initiative_id
WHERE t.initiative_id IS NOT NULL
  AND i.id IS NULL;

/* CHK-25: allocations.initiative_id must reference initiatives.id */
SELECT
  'CHK-25 orphan_allocations_initiative_id__ref_initiatives_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM allocations a
LEFT JOIN initiatives i ON i.id = a.initiative_id
WHERE a.initiative_id IS NOT NULL
  AND i.id IS NULL;

/* CHK-26: allocations.budget_line_id must reference budget_lines.id */
SELECT
  'CHK-26 orphan_allocations_budget_line_id__ref_budget_lines_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM allocations a
LEFT JOIN budget_lines bl ON bl.id = a.budget_line_id
WHERE a.budget_line_id IS NOT NULL
  AND bl.id IS NULL;

/* CHK-27: finance_transactions.initiative_id must reference initiatives.id (if not null) */
SELECT
  'CHK-27 orphan_finance_transactions_initiative_id__ref_initiatives_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM finance_transactions ft
LEFT JOIN initiatives i ON i.id = ft.initiative_id
WHERE ft.initiative_id IS NOT NULL
  AND i.id IS NULL;

/* CHK-28: finance_transactions.vendor_id must reference vendors.id (if not null) */
SELECT
  'CHK-28 orphan_finance_transactions_vendor_id__ref_vendors_id' AS check_name,
  COUNT(*) AS result_value,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM finance_transactions ft
LEFT JOIN vendors v ON v.id = ft.vendor_id
WHERE ft.vendor_id IS NOT NULL
  AND v.id IS NULL;

-- ============================================================
-- DIAGNOSTICS (violations only; may return 0 rows when PASS)
-- ============================================================

/* CHK-20_DIAG */
SELECT
  'CHK-20_DIAG orphan_users_role_id' AS diag_name,
  u.id, u.email, u.role_id, u.demo_marker, u.demo_dataset_id
FROM users u
LEFT JOIN roles r ON r.id = u.role_id
WHERE u.role_id IS NOT NULL
  AND r.id IS NULL
LIMIT 200;

/* CHK-21_DIAG */
SELECT
  'CHK-21_DIAG orphan_users_department_id' AS diag_name,
  u.id, u.email, u.department_id, u.demo_marker, u.demo_dataset_id
FROM users u
LEFT JOIN departments d ON d.id = u.department_id
WHERE u.department_id IS NOT NULL
  AND d.id IS NULL
LIMIT 200;

/* CHK-23_DIAG */
SELECT
  'CHK-23_DIAG orphan_initiatives_owner_id' AS diag_name,
  i.id, i.code, i.owner_id, i.demo_marker, i.demo_dataset_id
FROM initiatives i
LEFT JOIN users u ON u.id = i.owner_id
WHERE i.owner_id IS NOT NULL
  AND u.id IS NULL
LIMIT 200;

/* CHK-25_DIAG */
SELECT
  'CHK-25_DIAG orphan_allocations_initiative_id' AS diag_name,
  a.id, a.initiative_id, a.budget_line_id, a.demo_marker, a.demo_dataset_id
FROM allocations a
LEFT JOIN initiatives i ON i.id = a.initiative_id
WHERE a.initiative_id IS NOT NULL
  AND i.id IS NULL
LIMIT 200;

/* CHK-26_DIAG */
SELECT
  'CHK-26_DIAG orphan_allocations_budget_line_id' AS diag_name,
  a.id, a.initiative_id, a.budget_line_id, a.demo_marker, a.demo_dataset_id
FROM allocations a
LEFT JOIN budget_lines bl ON bl.id = a.budget_line_id
WHERE a.budget_line_id IS NOT NULL
  AND bl.id IS NULL
LIMIT 200;

/* CHK-28_DIAG */
SELECT
  'CHK-28_DIAG orphan_finance_transactions_vendor_id' AS diag_name,
  ft.id, ft.reference_no, ft.vendor_id, ft.demo_marker, ft.demo_dataset_id
FROM finance_transactions ft
LEFT JOIN vendors v ON v.id = ft.vendor_id
WHERE ft.vendor_id IS NOT NULL
  AND v.id IS NULL
LIMIT 200;

-- ============================================================
-- FINAL VERDICT NOTE
-- ============================================================

SELECT
  'BATCH_VERDICT_NOTE' AS note,
  'If any check result = FAIL, then batch verdict is FAIL; otherwise PASS.' AS rule;
