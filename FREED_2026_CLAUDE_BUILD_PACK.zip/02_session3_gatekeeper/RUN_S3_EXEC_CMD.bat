@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM ============================================================
REM RUN_S3_EXEC_CMD.bat (v1.1)
REM Session 3 (Gatekeeper) | DEMO_2026 | B1->B4 (ALL)
REM Enhancements:
REM  - Stable timestamps via PowerShell (locale-independent)
REM  - machine=%COMPUTERNAME%
REM  - finished_at accurate even across midnight
REM ============================================================

REM ---- REQUIRED CONFIG (edit these) ----
set "HOST=<HOST>"
set "PORT=<PORT>"
set "USER=<USER>"
set "DB=<DB_NAME>"
set "ENV_NAME=<ENV_NAME>"
set "OPERATOR=<NAME>"

REM ---- OPTIONAL CONFIG ----
set "SCRIPT=RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql"
set "PARSER=parse_gatekeeper_log.py"
set "PYTHON=python"
REM set "PYTHON=python3"
REM set "MYSQL=C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
set "MYSQL=mysql"

REM ---- PRECHECKS ----
if not exist "%SCRIPT%" (
  echo [ERROR] Missing script: %SCRIPT%
  exit /b 1
)

if /I "%MYSQL%"=="mysql" (
  where mysql >nul 2>&1
  if errorlevel 1 (
    echo [ERROR] mysql not found in PATH. Set MYSQL variable to full path of mysql.exe
    exit /b 1
  )
)

REM ---- STABLE TIMESTAMPS (PowerShell) ----
for /f "delims=" %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HHmmss"') do set "TS=%%I"
for /f "delims=" %%I in ('powershell -NoProfile -Command "Get-Date -Format ''yyyy-MM-dd HH:mm:ss''"') do set "STARTED_AT=%%I"

set "LOG=RESULT_GATEKEEPER_ALL_DEMO_2026_%TS%.log"
set "MACHINE=%COMPUTERNAME%"

REM --- LOG DIRECTORY (safe patch: keeps existing filename) ---
if "%LOG_DIR%"=="" set "LOG_DIR=logs\gatekeeper"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
for %%F in ("%LOG%") do set "LOG=%LOG_DIR%\%%~nxF"

REM ---- RUN_META ----
echo [RUN_META] env=%ENV_NAME% ^| host=%HOST% ^| db=%DB% ^| machine=%MACHINE% ^| pack=Session3_B1-B4 ^| script=%SCRIPT% ^| started_at=%STARTED_AT% ^| operator=%OPERATOR% > "%LOG%"

REM ---- RUN MYSQL (stdout+stderr -> log) ----
echo [RUN_STEP] mysql execute started...>> "%LOG%"
"%MYSQL%" --default-character-set=utf8mb4 -h "%HOST%" -P "%PORT%" -u "%USER%" -p "%DB%" --verbose --show-warnings < "%SCRIPT%" >> "%LOG%" 2>&1

REM ---- PARSE LOG (append RUN_RESULT) ----
if exist "%PARSER%" (
  echo [RUN_STEP] parser started...>> "%LOG%"
  "%PYTHON%" "%PARSER%" "%LOG%" >> "%LOG%" 2>&1
) else (
  echo [RUN_RESULT] verdict=UNKNOWN ^| failed_checks=UNKNOWN ^| log_file=%LOG% ^| notes=parser_missing:%PARSER%>> "%LOG%"
)

REM ---- RUN_END (stable) ----
for /f "delims=" %%I in ('powershell -NoProfile -Command "Get-Date -Format ''yyyy-MM-dd HH:mm:ss''"') do set "FINISHED_AT=%%I"
echo [RUN_END] finished_at=%FINISHED_AT% ^| machine=%MACHINE% ^| log_file=%LOG%>> "%LOG%"
echo [TRIAGE_NOTE] Any FAIL ^=^> FAIL. Focus: CHK-10/11/12/13/14 (Data), CHK-20..28 (Integrity), CHK-30/31 (Recon).>> "%LOG%"

echo [DONE] log_file=%LOG%
endlocal
