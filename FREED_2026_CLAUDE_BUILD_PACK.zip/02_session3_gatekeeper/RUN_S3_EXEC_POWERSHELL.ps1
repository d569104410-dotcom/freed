#requires -Version 5.1
<#!
RUN_S3_EXEC_POWERSHELL.ps1
Session 3 (Gatekeeper) | DEMO_2026 | B1->B4 (ALL)
Rules:
- Do NOT edit Gatekeeper SQL scripts during execution.
- Any change => Fix Attempt AFTER saving the log.
#>

# ---- REQUIRED CONFIG (edit these) ----
$HOST = "<HOST>"
$PORT = "<PORT>"
$USER = "<USER>"
$DB   = "<DB_NAME>"
$ENV  = "<ENV_NAME>"
$OP   = "<NAME>"

# ---- OPTIONAL CONFIG ----
$SCRIPT = "RUN_S3_GATEKEEPER_ALL_DEMO_2026.sql"
$PARSER = "parse_gatekeeper_log.py"
$PYTHON = $env:PYTHON_BIN
if ([string]::IsNullOrWhiteSpace($PYTHON)) { $PYTHON = "python" }

# ---- RUNTIME ----
$ts = Get-Date -Format "yyyy-MM-dd_HHmmss"
$start = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$log = "RESULT_GATEKEEPER_ALL_DEMO_2026_$ts.log"

# --- LOG DIRECTORY (safe patch: keeps existing filename) ---
$LogDir = $env:LOG_DIR
if ([string]::IsNullOrWhiteSpace($LogDir)) { $LogDir = "logs\gatekeeper" }
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$log = Join-Path $LogDir (Split-Path -Leaf $log)

"[RUN_META] env=$ENV | host=$HOST | db=$DB | pack=Session3_B1-B4 | script=$SCRIPT | started_at=$start | operator=$OP" | Tee-Object -FilePath $log

$mysqlArgs = @(
  "--default-character-set=utf8mb4",
  "-h", $HOST,
  "-P", $PORT,
  "-u", $USER,
  "-p",
  $DB,
  "--verbose",
  "--show-warnings"
)
$cmd = 'cmd /c "mysql ' + ($mysqlArgs -join ' ') + ' < "' + $SCRIPT + '" 2>&1"'
Invoke-Expression $cmd | Tee-Object -FilePath $log -Append

if (Test-Path $PARSER) {
  & $PYTHON $PARSER $log 2>&1 | Tee-Object -FilePath $log -Append
} else {
  "[RUN_RESULT] verdict=UNKNOWN | failed_checks=UNKNOWN | log_file=$log | notes=parser_missing:$PARSER" | Tee-Object -FilePath $log -Append
}

$end = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
"[RUN_END] finished_at=$end | log_file=$log" | Tee-Object -FilePath $log -Append
"[TRIAGE_NOTE] Any FAIL => FAIL. Focus: CHK-10/11/12/13/14 (Data), CHK-20..28 (Integrity), CHK-30/31 (Recon)." | Tee-Object -FilePath $log -Append
"[DONE] log_file=$log"
