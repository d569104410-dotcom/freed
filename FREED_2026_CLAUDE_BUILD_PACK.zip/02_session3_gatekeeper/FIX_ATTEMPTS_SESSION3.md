# FIX_ATTEMPTS_SESSION3.md

## Session 3 — Fix Attempts Register

### FA-001
- **Date:** `2026-02-24`
- **Type:** `Non-Logic / Organizational Patch`
- **Reason:** Route logs into `logs/gatekeeper/`
- **Artifacts:** `RUN_S3_EXEC_BASH.sh`, `RUN_S3_EXEC_POWERSHELL.ps1`, `RUN_S3_EXEC_CMD.bat`
- **Impact:** No execution logic change
- **Rule:** Future log naming format changes require a new Fix Attempt (do not bundle with path-only changes)

### FA-002
- **Date:** `2026-02-24`
- **Type:** `Non-Logic / Accuracy Patch (Counts Scope Tightening)`
- **Reason:** Tighten `CNT-04 demo_roles_count` to org-scoped demo roles only
- **Artifact:** `ACCEPTANCE_ADDENDUM_B1_DEMO_2026_CHECKS_ONLY.sql`
- **Patch:** Add `AND organization_id IS NOT NULL` while keeping `check_name` unchanged
- **Impact:** Improves precision only

### FA-003
- **Date:** `2026-02-24`
- **Type:** `Formatting Only Patch`
- **Reason:** Standardize batch wrappers (Header / Vars / Banner / Sections / Verdict)
- **Artifacts:** `RUN_S3_GATEKEEPER_B1_DEMO_2026.sql`, `RUN_S3_GATEKEEPER_B3_DEMO_2026.sql`, `RUN_S3_GATEKEEPER_B4_DEMO_2026.sql` (and optionally B2)
- **Impact:** No logic change expected
- **Precheck:** Use `FA003_PRECHECK_COMMANDS.md`
