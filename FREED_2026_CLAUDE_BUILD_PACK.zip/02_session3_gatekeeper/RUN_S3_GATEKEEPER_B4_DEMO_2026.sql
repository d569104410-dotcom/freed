-- ============================================================
-- RUN_S3_GATEKEEPER_B4_DEMO_2026.sql
-- SESSION 3 (Gatekeeper) | Batch 4/4 | RECONCILIATION Checks
-- Scope: Mostly DATASET (DEMO_2026)
-- Notes:
--   - Diagnostics queries included and may return 0 rows when PASS
--   - Includes safe CHK-31 execution (only runs if required columns exist)
-- ============================================================

SET @DATASET_ID := 'DEMO_2026';
SET @MONEY_TOLERANCE := 0.0001;
SET @FX_TOLERANCE := 0.0001;

SELECT CONCAT(
  '=== SESSION 3 (Gatekeeper) | Batch 4/4 (RECON) | DATASET=', @DATASET_ID,
  ' | MONEY_TOL=', @MONEY_TOLERANCE, ' | FX_TOL=', @FX_TOLERANCE,
  ' ==='
) AS session_banner;

-- ============================================================
-- CHECKS (PASS/FAIL rows)
-- ============================================================

/* CHK-30: initiatives dates valid (allow same day) => FAIL only if start_date > end_date */
SELECT
  'CHK-30 initiatives_dates_valid_start_le_end' AS check_name,
  COUNT(*) AS violations,
  0 AS expected_value,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM initiatives
WHERE demo_dataset_id=@DATASET_ID
  AND start_date IS NOT NULL
  AND end_date IS NOT NULL
  AND start_date > end_date;

/* CHK-31: finance_transactions amount_sar matches amount*exchange_rate (safe-run) */
SELECT
  'CHK-31 fin_amount_sar_matches_amount_x_rate' AS check_name,
  CASE
    WHEN (
      SELECT COUNT(*)
      FROM information_schema.columns
      WHERE table_schema = DATABASE()
        AND table_name = 'finance_transactions'
        AND column_name IN ('amount','exchange_rate','amount_sar')
    ) = 3
    THEN (
      SELECT COUNT(*)
      FROM finance_transactions
      WHERE demo_dataset_id=@DATASET_ID
        AND ABS(
          COALESCE(amount_sar,0) - (COALESCE(amount,0) * COALESCE(exchange_rate,0))
        ) >= @FX_TOLERANCE
    )
    ELSE NULL
  END AS violations,
  0 AS expected_value,
  CASE
    WHEN (
      SELECT COUNT(*)
      FROM information_schema.columns
      WHERE table_schema = DATABASE()
        AND table_name = 'finance_transactions'
        AND column_name IN ('amount','exchange_rate','amount_sar')
    ) <> 3
    THEN 'FAIL__MISSING_COLUMNS(amount,exchange_rate,amount_sar)'
    WHEN (
      SELECT COUNT(*)
      FROM finance_transactions
      WHERE demo_dataset_id=@DATASET_ID
        AND ABS(
          COALESCE(amount_sar,0) - (COALESCE(amount,0) * COALESCE(exchange_rate,0))
        ) >= @FX_TOLERANCE
    ) = 0
    THEN 'PASS'
    ELSE 'FAIL'
  END AS result;

-- ============================================================
-- DIAGNOSTICS (violations only; may return 0 rows when PASS)
-- ============================================================

/* CHK-30_DIAG: initiatives date violations */
SELECT
  'CHK-30_DIAG initiatives_date_violations' AS diag_name,
  id, code, start_date, end_date, demo_marker, demo_dataset_id
FROM initiatives
WHERE demo_dataset_id=@DATASET_ID
  AND start_date IS NOT NULL
  AND end_date IS NOT NULL
  AND start_date > end_date
LIMIT 200;

/* CHK-31_DIAG: safe diagnostics (dynamic only if columns exist) */
SET @has_chk31_cols :=
(
  SELECT CASE WHEN COUNT(*) = 3 THEN 1 ELSE 0 END
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'finance_transactions'
    AND column_name IN ('amount','exchange_rate','amount_sar')
);

SET @sql_chk31_diag := IF(
  @has_chk31_cols = 1,
  CONCAT(
    "SELECT 'CHK-31_DIAG fin_amount_sar_mismatch_rows' AS diag_name, ",
    "id, reference_no, amount, exchange_rate, amount_sar, ",
    "(COALESCE(amount,0) * COALESCE(exchange_rate,0)) AS computed_amount_sar, ",
    "(COALESCE(amount_sar,0) - (COALESCE(amount,0) * COALESCE(exchange_rate,0))) AS delta, ",
    "demo_marker, demo_dataset_id ",
    "FROM finance_transactions ",
    "WHERE demo_dataset_id='", @DATASET_ID, "' ",
    "AND ABS(COALESCE(amount_sar,0) - (COALESCE(amount,0) * COALESCE(exchange_rate,0))) >= ", @FX_TOLERANCE, " ",
    "ORDER BY ABS(COALESCE(amount_sar,0) - (COALESCE(amount,0) * COALESCE(exchange_rate,0))) DESC ",
    "LIMIT 200"
  ),
  "SELECT 'CHK-31_DIAG SKIPPED__MISSING_COLUMNS(amount,exchange_rate,amount_sar)' AS diag_name, 'No rows to show' AS note"
);

PREPARE stmt_chk31_diag FROM @sql_chk31_diag;
EXECUTE stmt_chk31_diag;
DEALLOCATE PREPARE stmt_chk31_diag;

-- ============================================================
-- FINAL VERDICT NOTE
-- ============================================================

SELECT
  'BATCH_VERDICT_NOTE' AS note,
  'If any check result = FAIL, then batch verdict is FAIL; otherwise PASS.' AS rule;
