# Freeze Notes — Session 1 (SSOT / Freeze Only) — Batch 1/4

## SSOT المعتمد (FINAL)
- Schema: `/install/schema.mysql.sql` = **Fix Attempt #1**
- Seed: `/install/seed.mysql.sql` = **Fix Attempt #1 Rev A**
  - مع تبديل `password_hash` فقط بالقيمة التالية EXACT:
  - `$2b$10$yKfK89/06PEobiIllvmRW.YxOnlfkGxDpSh4KrQHGbe6F6q8GHOUS`

## Freeze Date
- TBD (يُثبت عند الاعتماد النهائي بين جلسة 2 / جلسة 3)

## Scope
- Batch 1/4 فقط (Schema + Seed)

## Change Policy
- لا تغييرات أخرى (No other changes)
- التعديل الوحيد المسموح والمعتمد في seed هو استبدال قيمة `password_hash` فقط كما أعلاه

## Notes
- جلسة 1 = توثيق/Freeze فقط (SSOT)
- التنفيذ الفعلي والتحقق التشغيلي يتم في جلسة 3
- أي تعارض/تحسين/إعادة تصميم يُحال إلى جلسة 2 ثم يعود هنا للتثبيت
