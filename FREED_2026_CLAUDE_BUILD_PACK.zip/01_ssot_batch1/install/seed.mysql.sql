-- /install/seed.mysql.sql
-- ============================================================
-- FREED 2026 — Batch 1/4: Seed Data (INSERT ONLY) — Fix Attempt #1 Rev A
-- Changes: RBAC normalized, permissions=Bootstrap, role_permissions split by role type
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- SECTION 1: Bootstrap Data (demo_marker = 0, demo_dataset_id = NULL)
-- ============================================================

-- 1) Bootstrap Roles (organization_id = NULL للأدوار النظامية)
INSERT INTO roles (organization_id, name_ar, name_en, slug, description, level, status, demo_marker, demo_dataset_id) VALUES
(NULL, 'مدير النظام', 'System Administrator', 'system_admin', 'Full system access', 'system', 'active', 0, NULL),
(NULL, 'مدير المنظمة', 'Organization Admin', 'org_admin', 'Full organization management', 'organization', 'active', 0, NULL),
(NULL, 'مالي', 'Finance Manager', 'finance_manager', 'Financial operations and reporting', 'organization', 'active', 0, NULL),
(NULL, 'مدير مشروع', 'Project Manager', 'project_manager', 'Initiative and task management', 'department', 'active', 0, NULL),
(NULL, 'موظف', 'Staff Member', 'staff', 'Regular staff access', 'department', 'active', 0, NULL);

-- جلب IDs الأدوار الأساسية
SET @role_sysadmin_id := (SELECT id FROM roles WHERE slug='system_admin' AND organization_id IS NULL);
SET @role_orgadmin_id := (SELECT id FROM roles WHERE slug='org_admin' AND organization_id IS NULL);
SET @role_finance_id := (SELECT id FROM roles WHERE slug='finance_manager' AND organization_id IS NULL);
SET @role_projman_id := (SELECT id FROM roles WHERE slug='project_manager' AND organization_id IS NULL);
SET @role_staff_id := (SELECT id FROM roles WHERE slug='staff' AND organization_id IS NULL);

-- ============================================================
-- SECTION 2: Demo Data (demo_marker = 1, demo_dataset_id = 'DEMO_2026')
-- ============================================================

-- 2) Organizations
INSERT INTO organizations (name_ar, name_en, legal_type, registration_no, tax_id, contact_email, contact_phone, address, city, country, status, settings_json, demo_marker, demo_dataset_id) VALUES
('جمعية بر مشارق الخيرية', 'Bir Mashariq Charity Association', 'association', '1010567890', '310123456700003', 'info@brmsh.org', '0501234567', 'حي الروضة، شارع الملك فهد', 'الرياض', 'SA', 'active', '{"theme":"default","language":"ar"}', 1, 'DEMO_2026'),
('مؤسسة الأمل التعليمية', 'Al-Amal Educational Foundation', 'foundation', '1010987654', '310987654300003', 'contact@alamal.edu', '0509876543', 'حي النزهة، شارع الأمير سلطان', 'جدة', 'SA', 'active', '{"theme":"modern","language":"ar"}', 1, 'DEMO_2026');

-- جلب IDs المنظمات
SET @org1_id := (SELECT id FROM organizations WHERE demo_dataset_id='DEMO_2026' LIMIT 1);
SET @org2_id := (SELECT id FROM organizations WHERE demo_dataset_id='DEMO_2026' ORDER BY id DESC LIMIT 1);

-- 3) Departments
INSERT INTO departments (organization_id, name_ar, name_en, code, description, status, demo_marker, demo_dataset_id) VALUES
(@org1_id, 'الإدارة العامة', 'General Management', 'GM-001', 'الإدارة العليا للجمعية', 'active', 1, 'DEMO_2026'),
(@org1_id, 'الموارد البشرية', 'Human Resources', 'HR-001', 'شؤون الموظفين والمتطوعين', 'active', 1, 'DEMO_2026'),
(@org1_id, 'المالية والمحاسبة', 'Finance & Accounting', 'FIN-001', 'الشؤون المالية والموازنات', 'active', 1, 'DEMO_2026'),
(@org1_id, 'البرامج والمشاريع', 'Programs & Projects', 'PRG-001', 'إدارة المبادرات والمشاريع', 'active', 1, 'DEMO_2026'),
(@org2_id, 'الإدارة العامة', 'General Management', 'GM-001', 'الإدارة العليا للمؤسسة', 'active', 1, 'DEMO_2026');

SET @dept1_id := (SELECT id FROM departments WHERE organization_id=@org1_id AND code='GM-001');
SET @dept3_id := (SELECT id FROM departments WHERE organization_id=@org1_id AND code='FIN-001');
SET @dept4_id := (SELECT id FROM departments WHERE organization_id=@org1_id AND code='PRG-001');

-- 4) Demo Roles (للمنظمة الأولى)
INSERT INTO roles (organization_id, name_ar, name_en, slug, description, level, status, demo_marker, demo_dataset_id) VALUES
(@org1_id, 'مدير الجمعية', 'Association Manager', 'assoc_manager', 'مدير عام الجمعية', 'organization', 'active', 1, 'DEMO_2026'),
(@org1_id, 'أمين الصندوق', 'Treasurer', 'treasurer', 'أمين صندوق الجمعية', 'organization', 'active', 1, 'DEMO_2026'),
(@org1_id, 'محاسب', 'Accountant', 'accountant', 'محاسب الجمعية', 'department', 'active', 1, 'DEMO_2026'),
(@org1_id, 'منسق مشاريع', 'Project Coordinator', 'proj_coordinator', 'تنسيق المشاريع', 'department', 'active', 1, 'DEMO_2026');

SET @role_assoc_id := (SELECT id FROM roles WHERE organization_id=@org1_id AND slug='assoc_manager');
SET @role_treasurer_id := (SELECT id FROM roles WHERE organization_id=@org1_id AND slug='treasurer');
SET @role_acct_id := (SELECT id FROM roles WHERE organization_id=@org1_id AND slug='accountant');
SET @role_coord_id := (SELECT id FROM roles WHERE organization_id=@org1_id AND slug='proj_coordinator');

-- 5) Users (Demo)
INSERT INTO users (organization_id, department_id, role_id, email, password_hash, id_number, full_name_ar, full_name_en, phone, job_title, is_superadmin, email_verified_at, status, demo_marker, demo_dataset_id) VALUES
(@org1_id, @dept1_id, @role_assoc_id, 'admin@brmsh.org', '$2b$10$yKfK89/06PEobiIllvmRW.YxOnlfkGxDpSh4KrQHGbe6F6q8GHOUS', '1234567890', 'أحمد محمد العبدالله', 'Ahmed Mohammed Al-Abdullah', '0501111111', 'مدير عام', 1, NOW(), 'active', 1, 'DEMO_2026'),
(@org1_id, @dept3_id, @role_treasurer_id, 'finance@brmsh.org', '$2b$10$yKfK89/06PEobiIllvmRW.YxOnlfkGxDpSh4KrQHGbe6F6q8GHOUS', '1234567891', 'خالد عبدالرحمن السالم', 'Khaled Abdulrahman Al-Salem', '0502222222', 'أمين صندوق', 0, NOW(), 'active', 1, 'DEMO_2026'),
(@org1_id, @dept4_id, @role_coord_id, 'projects@brmsh.org', '$2b$10$yKfK89/06PEobiIllvmRW.YxOnlfkGxDpSh4KrQHGbe6F6q8GHOUS', '1234567892', 'سعد عبدالله القحطاني', 'Saad Abdullah Al-Qahtani', '0503333333', 'مدير برامج', 0, NOW(), 'active', 1, 'DEMO_2026');

SET @user1_id := (SELECT id FROM users WHERE email='admin@brmsh.org');
SET @user2_id := (SELECT id FROM users WHERE email='finance@brmsh.org');
SET @user3_id := (SELECT id FROM users WHERE email='projects@brmsh.org');

-- 6) Vendors
INSERT INTO vendors (organization_id, name_ar, name_en, commercial_reg_no, tax_id, contact_name, email, phone, city, category, status, demo_marker, demo_dataset_id) VALUES
(@org1_id, 'مؤسسة التقنية المتقدمة', 'Advanced Tech Est.', '1010123456', '300123456700001', 'محمد علي', 'sales@advtech.sa', '0111234567', 'الرياض', 'تقنية معلومات', 'active', 1, 'DEMO_2026'),
(@org1_id, 'شركة النقل السريع', 'Fast Transport Co.', '1010654321', '300765432100002', 'عمر حسين', 'info@fasttransport.sa', '0139876543', 'الدمام', 'نقل ومواصلات', 'active', 1, 'DEMO_2026'),
(@org1_id, 'مطبعة الرؤية', 'Al-Roya Printing', '1010789012', '300789012300003', 'فهد سليمان', 'print@alroya.sa', '0123456789', 'جدة', 'طباعة ونشر', 'active', 1, 'DEMO_2026');

SET @vendor1_id := (SELECT id FROM vendors WHERE organization_id=@org1_id LIMIT 1);

-- 7) Budget Lines
INSERT INTO budget_lines (organization_id, department_id, code, name_ar, name_en, line_type, fiscal_year, original_amount, description, status, demo_marker, demo_dataset_id) VALUES
(@org1_id, @dept3_id, 'EXP-001', 'مصاريف تشغيلية', 'Operating Expenses', 'expense', 2026, 500000.00, 'المصاريف التشغيلية العامة', 'active', 1, 'DEMO_2026'),
(@org1_id, @dept4_id, 'PRJ-001', 'مشاريع الخير', 'Charity Projects', 'expense', 2026, 1000000.00, 'ميزانية المشاريع الخيرية', 'active', 1, 'DEMO_2026'),
(@org1_id, @dept3_id, 'REV-001', 'تبرعات نقدية', 'Cash Donations', 'revenue', 2026, 2000000.00, 'التبرعات النقدية المتوقعة', 'active', 1, 'DEMO_2026');

SET @budget2_id := (SELECT id FROM budget_lines WHERE code='PRJ-001' AND organization_id=@org1_id);

-- 8) Initiatives
INSERT INTO initiatives (organization_id, department_id, owner_id, code, title_ar, title_en, description, objectives, start_date, end_date, total_budget, status, priority, created_by, demo_marker, demo_dataset_id) VALUES
(@org1_id, @dept4_id, @user1_id, 'INIT-2026-001', 'حملة الإفطار الرمضاني 2026', 'Ramadan Iftar Campaign 2026', 'تقديم وجبات إفطار للمحتاجين خلال شهر رمضان', 'إطعام 10,000 صائم', '2026-02-15', '2026-04-15', 300000.00, 'active', 'high', @user1_id, 1, 'DEMO_2026'),
(@org1_id, @dept4_id, @user1_id, 'INIT-2026-002', 'كفالة الأيتام', 'Orphans Sponsorship', 'كفالة 500 يتيم للعام 2026', 'ضمان مستقبل 500 يتيم تعليمياً وصحياً', '2026-01-01', '2026-12-31', 600000.00, 'planning', 'critical', @user1_id, 1, 'DEMO_2026');

SET @init1_id := (SELECT id FROM initiatives WHERE code='INIT-2026-001' AND organization_id=@org1_id);
SET @init2_id := (SELECT id FROM initiatives WHERE code='INIT-2026-002' AND organization_id=@org1_id);

-- 9) Tasks
INSERT INTO tasks (initiative_id, assignee_id, code, title_ar, title_en, description, task_type, start_date, due_date, estimated_hours, cost_estimate, status, priority, created_by, demo_marker, demo_dataset_id) VALUES
(@init1_id, @user3_id, 'TSK-001', 'شراء المواد الغذائية', 'Purchase Food Supplies', 'شراء التمور والأرز والزيت للحملة', 'task', '2026-02-15', '2026-02-28', 40, 100000.00, 'todo', 'high', @user1_id, 1, 'DEMO_2026'),
(@init1_id, @user3_id, 'TSK-002', 'تأجير المستودع', 'Warehouse Rental', 'تأجير مستودع لتخزين المواد', 'task', '2026-02-10', '2026-02-20', 10, 20000.00, 'in_progress', 'medium', @user1_id, 1, 'DEMO_2026'),
(@init1_id, NULL, 'MIL-001', 'انطلاق الحملة', 'Campaign Launch', 'بداية توزيع الوجبات', 'milestone', '2026-03-01', '2026-03-01', 0, 0.00, 'backlog', 'critical', @user1_id, 1, 'DEMO_2026');

-- 10) Allocations
INSERT INTO allocations (organization_id, initiative_id, budget_line_id, fiscal_year, allocation_type, allocated_amount, spent_amount, committed_amount, available_amount, start_date, end_date, status, description, approved_by, approved_at, created_by, demo_marker, demo_dataset_id) VALUES
(@org1_id, @init1_id, @budget2_id, 2026, 'operational', 300000.00, 50000.00, 100000.00, 150000.00, '2026-02-01', '2026-04-30', 'active', 'اعتماد حملة الإفطار', @user1_id, NOW(), @user1_id, 1, 'DEMO_2026'),
(@org1_id, @init2_id, @budget2_id, 2026, 'operational', 600000.00, 0.00, 0.00, 600000.00, '2026-01-01', '2026-12-31', 'active', 'اعتماد كفالة الأيتام', @user1_id, NOW(), @user1_id, 1, 'DEMO_2026');

-- ============================================================
-- SECTION 3: RBAC Permissions (Bootstrap — غير قابلة للتعديل)
-- ============================================================

-- 11) Permissions Master Data (Bootstrap: 0, NULL)
INSERT INTO permissions (permission_key, module, action, description, demo_marker, demo_dataset_id) VALUES
('system.all', 'system', 'all', 'Full system access', 0, NULL),
('organizations.manage', 'organizations', 'manage', 'Manage organizations', 0, NULL),
('users.manage', 'users', 'manage', 'Manage users', 0, NULL),
('settings.manage', 'settings', 'manage', 'Manage settings', 0, NULL),
('finance.manage', 'finance', 'manage', 'Manage finance', 0, NULL),
('finance.view', 'finance', 'view', 'View finance', 0, NULL),
('reports.view', 'reports', 'view', 'View reports', 0, NULL),
('initiatives.manage', 'initiatives', 'manage', 'Manage initiatives', 0, NULL),
('tasks.manage', 'tasks', 'manage', 'Manage tasks', 0, NULL),
('tasks.view', 'tasks', 'view', 'View tasks', 0, NULL),
('tasks.assign', 'tasks', 'assign', 'Assign tasks', 0, NULL),
('team.view', 'team', 'view', 'View team', 0, NULL),
('profile.edit', 'profile', 'edit', 'Edit profile', 0, NULL),
('transactions.approve', 'transactions', 'approve', 'Approve transactions', 0, NULL),
('transactions.create', 'transactions', 'create', 'Create transactions', 0, NULL);

-- جلب IDs الأذونات
SET @perm_system_all := (SELECT id FROM permissions WHERE permission_key='system.all');
SET @perm_org_manage := (SELECT id FROM permissions WHERE permission_key='organizations.manage');
SET @perm_user_manage := (SELECT id FROM permissions WHERE permission_key='users.manage');
SET @perm_setting_manage := (SELECT id FROM permissions WHERE permission_key='settings.manage');
SET @perm_fin_manage := (SELECT id FROM permissions WHERE permission_key='finance.manage');
SET @perm_fin_view := (SELECT id FROM permissions WHERE permission_key='finance.view');
SET @perm_report_view := (SELECT id FROM permissions WHERE permission_key='reports.view');
SET @perm_init_manage := (SELECT id FROM permissions WHERE permission_key='initiatives.manage');
SET @perm_task_manage := (SELECT id FROM permissions WHERE permission_key='tasks.manage');
SET @perm_task_view := (SELECT id FROM permissions WHERE permission_key='tasks.view');
SET @perm_task_assign := (SELECT id FROM permissions WHERE permission_key='tasks.assign');
SET @perm_team_view := (SELECT id FROM permissions WHERE permission_key='team.view');
SET @perm_profile_edit := (SELECT id FROM permissions WHERE permission_key='profile.edit');
SET @perm_txn_approve := (SELECT id FROM permissions WHERE permission_key='transactions.approve');
SET @perm_txn_create := (SELECT id FROM permissions WHERE permission_key='transactions.create');

-- 12) Role Permissions Links — BOOTSTRAP ROLES (0, NULL)
INSERT INTO role_permissions (role_id, permission_id, scope_type, granted_by, demo_marker, demo_dataset_id) VALUES
(@role_sysadmin_id, @perm_system_all, 'GLOBAL', NULL, 0, NULL),
(@role_orgadmin_id, @perm_org_manage, 'GLOBAL', NULL, 0, NULL),
(@role_orgadmin_id, @perm_user_manage, 'GLOBAL', NULL, 0, NULL),
(@role_orgadmin_id, @perm_setting_manage, 'GLOBAL', NULL, 0, NULL),
(@role_finance_id, @perm_fin_manage, 'GLOBAL', NULL, 0, NULL),
(@role_finance_id, @perm_report_view, 'GLOBAL', NULL, 0, NULL),
(@role_projman_id, @perm_init_manage, 'GLOBAL', NULL, 0, NULL),
(@role_projman_id, @perm_task_manage, 'GLOBAL', NULL, 0, NULL),
(@role_projman_id, @perm_team_view, 'GLOBAL', NULL, 0, NULL),
(@role_staff_id, @perm_task_view, 'GLOBAL', NULL, 0, NULL),
(@role_staff_id, @perm_profile_edit, 'GLOBAL', NULL, 0, NULL);

-- 13) Role Permissions Links — DEMO ROLES (1, DEMO_2026) 
INSERT INTO role_permissions (role_id, permission_id, scope_type, granted_by, demo_marker, demo_dataset_id) VALUES
(@role_assoc_id, @perm_system_all, 'GLOBAL', @user1_id, 1, 'DEMO_2026'),
(@role_treasurer_id, @perm_fin_manage, 'GLOBAL', @user1_id, 1, 'DEMO_2026'),
(@role_treasurer_id, @perm_txn_approve, 'GLOBAL', @user1_id, 1, 'DEMO_2026'),
(@role_acct_id, @perm_fin_view, 'GLOBAL', @user1_id, 1, 'DEMO_2026'),
(@role_acct_id, @perm_txn_create, 'GLOBAL', @user1_id, 1, 'DEMO_2026'),
(@role_coord_id, @perm_init_manage, 'GLOBAL', @user1_id, 1, 'DEMO_2026'),
(@role_coord_id, @perm_task_assign, 'GLOBAL', @user1_id, 1, 'DEMO_2026');

-- ============================================================
-- SECTION 4: Finance & Audit (No Hardcoded IDs)
-- ============================================================

-- 14) Finance Transactions
INSERT INTO finance_transactions (organization_id, initiative_id, transaction_type, category, subcategory, amount, currency_code, amount_sar, transaction_date, fiscal_year, fiscal_period, description, reference_no, vendor_id, payment_method, approval_status, approved_by, approved_at, created_by, demo_marker, demo_dataset_id) VALUES
(@org1_id, @init1_id, 'expense', 'مشتريات', 'مواد غذائية', 50000.00, 'SAR', 50000.00, '2026-02-20', 2026, 1, 'دفعة أولى لشراء تمور', 'INV-2026-001', @vendor1_id, 'bank_transfer', 'approved', @user1_id, NOW(), @user2_id, 1, 'DEMO_2026'),
(@org1_id, NULL, 'income', 'تبرعات', 'تبرع نقدي', 200000.00, 'SAR', 200000.00, '2026-02-01', 2026, 1, 'تبرع كريم من أحد المحسنين', 'RCPT-2026-001', NULL, 'bank_transfer', 'approved', @user1_id, NOW(), @user1_id, 1, 'DEMO_2026'),
(@org1_id, @init1_id, 'expense', 'تشغيل', 'إيجار', 15000.00, 'SAR', 15000.00, '2026-02-18', 2026, 1, 'إيجار مستودع الحملة', 'INV-2026-002', @vendor1_id, 'check', 'pending', NULL, NULL, @user2_id, 1, 'DEMO_2026');

-- جلب ID المعاملة المالية بدون Hardcode
SET @txn1_id := (SELECT id FROM finance_transactions WHERE organization_id=@org1_id AND reference_no='INV-2026-001' LIMIT 1);

-- 15) Attachments (استخدام @txn1_id)
INSERT INTO attachments (organization_id, entity_type, entity_id, file_name, original_name, mime_type, file_size, storage_path, checksum_sha256, uploaded_by, description, demo_marker, demo_dataset_id) VALUES
(@org1_id, 'finance_transactions', @txn1_id, 'inv_001.pdf', 'فاتورة_شراء_تمور.pdf', 'application/pdf', 204800, '/uploads/2026/inv_001.pdf', 'a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456', @user2_id, 'فاتورة شراء التمور', 1, 'DEMO_2026'),
(@org1_id, 'initiatives', @init1_id, 'plan_2026.pdf', 'خطة_الحملة.pdf', 'application/pdf', 512000, '/uploads/2026/plan_2026.pdf', 'b2c3d4e5f6a7890123456789012345678901abcdef1234567890abcdef1234567', @user1_id, 'خطة الحملة الرمضانية', 1, 'DEMO_2026');

-- 16) Event Log (استخدام @txn1_id)
INSERT INTO event_log (organization_id, user_id, event_type, entity_type, entity_id, action, payload, ip_address, severity, demo_marker, demo_dataset_id) VALUES
(@org1_id, @user1_id, 'user_login', 'users', @user1_id, 'login', '{"ip":"192.168.1.100","user_agent":"Mozilla/5.0","method":"password"}', '192.168.1.100', 'info', 1, 'DEMO_2026'),
(@org1_id, @user1_id, 'initiative_created', 'initiatives', @init1_id, 'create', '{"title":"حملة الإفطار","budget":300000}', '192.168.1.100', 'info', 1, 'DEMO_2026'),
(@org1_id, @user2_id, 'transaction_approved', 'finance_transactions', @txn1_id, 'approve', '{"amount":50000,"approved_by":1}', '192.168.1.101', 'info', 1, 'DEMO_2026');

-- 17) Audit Log (استخدام @txn1_id)
INSERT INTO audit_log (organization_id, user_id, table_name, record_id, action, old_values, new_values, changed_fields, ip_address, transaction_id, demo_marker, demo_dataset_id) VALUES
(@org1_id, @user1_id, 'initiatives', @init1_id, 'INSERT', NULL, '{"title":"حملة الإفطار","status":"active","budget":300000}', '["title","status","budget"]', '192.168.1.100', 'TXN-20260224-001', 1, 'DEMO_2026'),
(@org1_id, @user2_id, 'finance_transactions', @txn1_id, 'UPDATE', '{"status":"pending"}', '{"status":"approved","approved_by":1}', '["status","approved_by"]', '192.168.1.101', 'TXN-20260224-002', 1, 'DEMO_2026');

SET FOREIGN_KEY_CHECKS = 1;
-- End of Seed
