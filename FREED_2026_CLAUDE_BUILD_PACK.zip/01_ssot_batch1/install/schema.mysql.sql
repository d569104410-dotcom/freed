-- /install/schema.mysql.sql
-- ============================================================
-- FREED 2026 — Batch 1/4: Schema (DDL ONLY) — Fix Attempt #1
-- MySQL 8.0
-- Changes: RBAC normalized (no JSON), roles.org_id nullable, FKs at end only
-- ============================================================

-- --------------------------------------------------------
-- 1) Organizations
-- --------------------------------------------------------
CREATE TABLE organizations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name_ar VARCHAR(255) NOT NULL,
    name_en VARCHAR(255) NULL,
    legal_type ENUM('association','foundation','cooperative','civil_company') NOT NULL,
    registration_no VARCHAR(100) NULL,
    tax_id VARCHAR(100) NULL,
    contact_email VARCHAR(255) NULL,
    contact_phone VARCHAR(50) NULL,
    address TEXT NULL,
    city VARCHAR(100) NULL,
    country VARCHAR(100) DEFAULT 'SA',
    postal_code VARCHAR(20) NULL,
    logo_url VARCHAR(500) NULL,
    website VARCHAR(255) NULL,
    founded_date DATE NULL,
    fiscal_year_start DATE NULL,
    status ENUM('active','suspended','dissolved') DEFAULT 'active',
    settings_json JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_legal_type (legal_type),
    INDEX idx_status (status),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 2) Departments
-- --------------------------------------------------------
CREATE TABLE departments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    parent_id BIGINT UNSIGNED NULL,
    name_ar VARCHAR(255) NOT NULL,
    name_en VARCHAR(255) NULL,
    code VARCHAR(50) NULL,
    description TEXT NULL,
    manager_id BIGINT UNSIGNED NULL,
    budget_ceiling DECIMAL(15,2) NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_parent (parent_id),
    INDEX idx_status (status),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 3) Roles (RBAC) — organization_id NULLable للأدوار النظامية
-- --------------------------------------------------------
CREATE TABLE roles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NULL,
    name_ar VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NULL,
    slug VARCHAR(100) NOT NULL,
    description TEXT NULL,
    level ENUM('system','organization','department','project') DEFAULT 'organization',
    inherits_from BIGINT UNSIGNED NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org_slug (organization_id, slug),
    INDEX idx_level (level),
    INDEX idx_status (status),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 4) Permissions (RBAC normalized — بدلاً من JSON)
-- --------------------------------------------------------
CREATE TABLE permissions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    permission_key VARCHAR(100) NOT NULL UNIQUE,
    module VARCHAR(50) NOT NULL,
    action VARCHAR(50) NOT NULL,
    description TEXT NULL,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_module_action (module, action),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 5) Role Permissions (RBAC normalized — علاقات Many-to-Many)
-- --------------------------------------------------------
CREATE TABLE role_permissions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_id BIGINT UNSIGNED NOT NULL,
    permission_id BIGINT UNSIGNED NOT NULL,
    scope_type ENUM('GLOBAL','DEPARTMENT','INITIATIVE','SELF') NOT NULL DEFAULT 'GLOBAL',
    scope_value BIGINT UNSIGNED NULL,
    granted_by BIGINT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    UNIQUE KEY uk_role_perm_scope (role_id, permission_id, scope_type, scope_value),
    INDEX idx_role (role_id),
    INDEX idx_permission (permission_id),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 6) Users
-- --------------------------------------------------------
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    department_id BIGINT UNSIGNED NULL,
    role_id BIGINT UNSIGNED NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    id_number VARCHAR(50) NULL,
    full_name_ar VARCHAR(255) NOT NULL,
    full_name_en VARCHAR(255) NULL,
    phone VARCHAR(50) NULL,
    job_title VARCHAR(100) NULL,
    avatar_url VARCHAR(500) NULL,
    is_superadmin TINYINT(1) DEFAULT 0,
    email_verified_at TIMESTAMP NULL,
    last_login_at TIMESTAMP NULL,
    failed_login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL,
    status ENUM('active','inactive','suspended','pending') DEFAULT 'pending',
    preferences_json JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    UNIQUE KEY uk_email (email),
    INDEX idx_org (organization_id),
    INDEX idx_dept (department_id),
    INDEX idx_role (role_id),
    INDEX idx_status (status),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 7) Initiatives
-- --------------------------------------------------------
CREATE TABLE initiatives (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    department_id BIGINT UNSIGNED NULL,
    owner_id BIGINT UNSIGNED NOT NULL,
    code VARCHAR(50) NOT NULL,
    title_ar VARCHAR(255) NOT NULL,
    title_en VARCHAR(255) NULL,
    description TEXT NULL,
    objectives TEXT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    actual_start_date DATE NULL,
    actual_end_date DATE NULL,
    total_budget DECIMAL(15,2) DEFAULT 0.00,
    spent_amount DECIMAL(15,2) DEFAULT 0.00,
    status ENUM('draft','planning','active','paused','completed','cancelled') DEFAULT 'draft',
    priority ENUM('low','medium','high','critical') DEFAULT 'medium',
    progress_percent DECIMAL(5,2) DEFAULT 0.00,
    parent_id BIGINT UNSIGNED NULL,
    metadata_json JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_dept (department_id),
    INDEX idx_owner (owner_id),
    INDEX idx_status (status),
    INDEX idx_dates (start_date, end_date),
    INDEX idx_parent (parent_id),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 8) Tasks
-- --------------------------------------------------------
CREATE TABLE tasks (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    initiative_id BIGINT UNSIGNED NOT NULL,
    assignee_id BIGINT UNSIGNED NULL,
    parent_id BIGINT UNSIGNED NULL,
    code VARCHAR(50) NOT NULL,
    title_ar VARCHAR(255) NOT NULL,
    title_en VARCHAR(255) NULL,
    description TEXT NULL,
    task_type ENUM('task','milestone','phase','deliverable') DEFAULT 'task',
    start_date DATE NULL,
    due_date DATE NULL,
    completed_at TIMESTAMP NULL,
    estimated_hours DECIMAL(8,2) NULL,
    actual_hours DECIMAL(8,2) NULL,
    cost_estimate DECIMAL(12,2) NULL,
    status ENUM('backlog','todo','in_progress','review','done','cancelled') DEFAULT 'backlog',
    priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
    progress_percent DECIMAL(5,2) DEFAULT 0.00,
    dependencies_json JSON NULL,
    attachments_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_initiative (initiative_id),
    INDEX idx_assignee (assignee_id),
    INDEX idx_parent (parent_id),
    INDEX idx_status (status),
    INDEX idx_dates (due_date),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 9) Finance Transactions (SSOT المالية)
-- --------------------------------------------------------
CREATE TABLE finance_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    initiative_id BIGINT UNSIGNED NULL,
    transaction_type ENUM('income','expense','transfer','adjustment') NOT NULL,
    category VARCHAR(100) NOT NULL,
    subcategory VARCHAR(100) NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency_code CHAR(3) DEFAULT 'SAR',
    exchange_rate DECIMAL(10,6) DEFAULT 1.000000,
    amount_sar DECIMAL(15,2) NOT NULL,
    transaction_date DATE NOT NULL,
    fiscal_year INT NOT NULL,
    fiscal_period TINYINT NOT NULL,
    description TEXT NULL,
    reference_no VARCHAR(100) NULL,
    document_no VARCHAR(100) NULL,
    vendor_id BIGINT UNSIGNED NULL,
    payment_method ENUM('cash','bank_transfer','check','credit_card','other') NULL,
    bank_account_id BIGINT UNSIGNED NULL,
    approval_status ENUM('draft','pending','approved','rejected') DEFAULT 'draft',
    approved_by BIGINT UNSIGNED NULL,
    approved_at TIMESTAMP NULL,
    posted_to_gl TINYINT(1) DEFAULT 0,
    gl_entry_id BIGINT UNSIGNED NULL,
    metadata_json JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_initiative (initiative_id),
    INDEX idx_type (transaction_type),
    INDEX idx_date (transaction_date),
    INDEX idx_fiscal (fiscal_year, fiscal_period),
    INDEX idx_status (approval_status),
    INDEX idx_vendor (vendor_id),
    INDEX idx_ref_no (reference_no),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 10) Allocations (SSOT — لا يوجد finance_allocations)
-- --------------------------------------------------------
CREATE TABLE allocations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    initiative_id BIGINT UNSIGNED NOT NULL,
    budget_line_id BIGINT UNSIGNED NULL,
    fiscal_year INT NOT NULL,
    allocation_type ENUM('operational','capital','emergency','reserve') DEFAULT 'operational',
    allocated_amount DECIMAL(15,2) NOT NULL,
    spent_amount DECIMAL(15,2) DEFAULT 0.00,
    committed_amount DECIMAL(15,2) DEFAULT 0.00,
    available_amount DECIMAL(15,2) NOT NULL,
    currency_code CHAR(3) DEFAULT 'SAR',
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('active','frozen','closed','cancelled') DEFAULT 'active',
    description TEXT NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_initiative (initiative_id),
    INDEX idx_budget_line (budget_line_id),
    INDEX idx_fiscal (fiscal_year),
    INDEX idx_status (status),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 11) Budget Lines
-- --------------------------------------------------------
CREATE TABLE budget_lines (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    department_id BIGINT UNSIGNED NULL,
    parent_id BIGINT UNSIGNED NULL,
    code VARCHAR(50) NOT NULL,
    name_ar VARCHAR(255) NOT NULL,
    name_en VARCHAR(255) NULL,
    line_type ENUM('revenue','expense','asset','liability') DEFAULT 'expense',
    fiscal_year INT NOT NULL,
    original_amount DECIMAL(15,2) NOT NULL,
    revised_amount DECIMAL(15,2) NULL,
    spent_amount DECIMAL(15,2) DEFAULT 0.00,
    description TEXT NULL,
    account_code VARCHAR(50) NULL,
    status ENUM('active','inactive','closed') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_dept (department_id),
    INDEX idx_parent (parent_id),
    INDEX idx_fiscal (fiscal_year),
    INDEX idx_type (line_type),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 12) Vendors
-- --------------------------------------------------------
CREATE TABLE vendors (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    name_ar VARCHAR(255) NOT NULL,
    name_en VARCHAR(255) NULL,
    commercial_reg_no VARCHAR(50) NULL,
    tax_id VARCHAR(50) NULL,
    contact_name VARCHAR(255) NULL,
    email VARCHAR(255) NULL,
    phone VARCHAR(50) NULL,
    address TEXT NULL,
    city VARCHAR(100) NULL,
    bank_account VARCHAR(100) NULL,
    bank_iban VARCHAR(50) NULL,
    bank_name VARCHAR(100) NULL,
    category VARCHAR(100) NULL,
    status ENUM('active','inactive','blacklisted') DEFAULT 'active',
    rating DECIMAL(3,2) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_status (status),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 13) Attachments
-- --------------------------------------------------------
CREATE TABLE attachments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id BIGINT UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    file_size BIGINT UNSIGNED NOT NULL,
    storage_path VARCHAR(500) NOT NULL,
    checksum_sha256 VARCHAR(64) NOT NULL,
    uploaded_by BIGINT UNSIGNED NOT NULL,
    description TEXT NULL,
    is_encrypted TINYINT(1) DEFAULT 0,
    tags_json JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_org (organization_id),
    INDEX idx_uploaded_by (uploaded_by),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 14) Event Log (JSON مسموح فقط في payload)
-- --------------------------------------------------------
CREATE TABLE event_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    event_type VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id BIGINT UNSIGNED NOT NULL,
    action VARCHAR(50) NOT NULL,
    payload JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    severity ENUM('info','warning','error','critical') DEFAULT 'info',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_user (user_id),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_event_type (event_type),
    INDEX idx_created (created_at),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 15) Audit Log (JSON مسموح فقط في old_values/new_values)
-- --------------------------------------------------------
CREATE TABLE audit_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    table_name VARCHAR(100) NOT NULL,
    record_id BIGINT UNSIGNED NOT NULL,
    action ENUM('INSERT','UPDATE','DELETE') NOT NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    changed_fields JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    transaction_id VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    demo_marker TINYINT(1) NOT NULL DEFAULT 0,
    demo_dataset_id VARCHAR(50) NULL,
    INDEX idx_org (organization_id),
    INDEX idx_user (user_id),
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at),
    INDEX idx_demo (demo_marker, demo_dataset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- FOREIGN KEYS (ALL AT THE END ONLY via ALTER TABLE)
-- ============================================================

ALTER TABLE departments 
    ADD CONSTRAINT fk_dept_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_dept_parent FOREIGN KEY (parent_id) REFERENCES departments(id) ON DELETE SET NULL;

ALTER TABLE roles 
    ADD CONSTRAINT fk_role_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_role_inherits FOREIGN KEY (inherits_from) REFERENCES roles(id) ON DELETE SET NULL;

ALTER TABLE role_permissions
    ADD CONSTRAINT fk_role_perm_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_role_perm_permission FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_role_perm_granted_by FOREIGN KEY (granted_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE users 
    ADD CONSTRAINT fk_user_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_user_dept FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_user_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_user_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_user_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE initiatives 
    ADD CONSTRAINT fk_init_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_init_dept FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_init_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_init_parent FOREIGN KEY (parent_id) REFERENCES initiatives(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_init_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_init_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE tasks 
    ADD CONSTRAINT fk_task_initiative FOREIGN KEY (initiative_id) REFERENCES initiatives(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_task_assignee FOREIGN KEY (assignee_id) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_task_parent FOREIGN KEY (parent_id) REFERENCES tasks(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_task_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_task_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE finance_transactions 
    ADD CONSTRAINT fk_fin_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_fin_initiative FOREIGN KEY (initiative_id) REFERENCES initiatives(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_fin_vendor FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_fin_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_fin_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_fin_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE allocations 
    ADD CONSTRAINT fk_alloc_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_alloc_initiative FOREIGN KEY (initiative_id) REFERENCES initiatives(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_alloc_budget_line FOREIGN KEY (budget_line_id) REFERENCES budget_lines(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_alloc_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_alloc_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_alloc_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE budget_lines 
    ADD CONSTRAINT fk_budget_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_budget_dept FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_budget_parent FOREIGN KEY (parent_id) REFERENCES budget_lines(id) ON DELETE SET NULL;

ALTER TABLE vendors 
    ADD CONSTRAINT fk_vendor_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE;

ALTER TABLE attachments 
    ADD CONSTRAINT fk_attach_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_attach_user FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE RESTRICT;

ALTER TABLE event_log 
    ADD CONSTRAINT fk_event_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_event_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE audit_log 
    ADD CONSTRAINT fk_audit_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;

-- End of Schema
